#include "xor.h"
#include <TlHelp32.h>
#include <Windows.h>

#define MEDreadwyy CTL_CODE(FILE_DEVICE_UNKNOWN, 0x07D, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define MEDbab3 CTL_CODE(FILE_DEVICE_UNKNOWN, 0x09A, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define Scode_security 0x85b3e20

typedef struct _readwrite {
    INT32 security;
    INT32 process_id;
    ULONGLONG address;
    ULONGLONG buffer;
    ULONGLONG size;
    BOOLEAN write;
} rw, * prw;

typedef struct _ba {
    INT32 security;
    INT32 process_id;
    ULONGLONG* address;
} ba, * pba;

typedef struct _ga {
    INT32 security;
    ULONGLONG* address;
} ga, * pga;

class CDriver {
public:
    HANDLE driver_handle;
    INT32 process_id;

    CDriver() : driver_handle(INVALID_HANDLE_VALUE), process_id(0) {}

    // Attempts to obtain a handle to the driver
    bool find_driver() {
        driver_handle = CreateFileW(
            L"\\\\.\\MedusaNewCom",
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_EXISTING,
            0,
            nullptr
        );
        return (driver_handle != INVALID_HANDLE_VALUE);
    }

    // Reads from physical memory using the driver
    void read_physical(PVOID address, PVOID buffer, DWORD size) {
        _readwrite arguments = { 0 };
        arguments.security = Scode_security;
        arguments.address = (ULONGLONG)address;
        arguments.buffer = (ULONGLONG)buffer;
        arguments.size = size;
        arguments.process_id = process_id;
        arguments.write = FALSE;

        DeviceIoControl(driver_handle, MEDreadwyy, &arguments, sizeof(arguments), nullptr, 0, nullptr, nullptr);
    }

    // Writes to physical memory using the driver
    void write_physical(PVOID address, PVOID buffer, DWORD size) {
        _readwrite arguments = { 0 };
        arguments.security = Scode_security;
        arguments.address = (ULONGLONG)address;
        arguments.buffer = (ULONGLONG)buffer;
        arguments.size = size;
        arguments.process_id = process_id;
        arguments.write = TRUE;

        DeviceIoControl(driver_handle, MEDreadwyy, &arguments, sizeof(arguments), nullptr, 0, nullptr, nullptr);
    }

    // Returns the image base address from the driver
    uintptr_t find_image() {
        uintptr_t image_address = 0;
        _ba arguments = { 0 };
        arguments.security = Scode_security;
        arguments.process_id = process_id;
        arguments.address = (ULONGLONG*)&image_address;

        DeviceIoControl(driver_handle, MEDbab3, &arguments, sizeof(arguments), nullptr, 0, nullptr, nullptr);

        return image_address;
    }

    // Locates the process id by process name using the Toolhelp snapshot API
    INT32 find_process(LPCTSTR process_name) {
        PROCESSENTRY32 pe32 = { 0 };
        pe32.dwSize = sizeof(PROCESSENTRY32);
        HANDLE hsnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hsnap == INVALID_HANDLE_VALUE)
            return 0;

        if (Process32First(hsnap, &pe32)) {
            do {
                if (!lstrcmpi(pe32.szExeFile, process_name)) {
                    process_id = pe32.th32ProcessID;
                    CloseHandle(hsnap);
                    return process_id;
                }
            } while (Process32Next(hsnap, &pe32));
        }
        CloseHandle(hsnap);
        return process_id;
    }

    // Template function for reading data from memory
    template <typename T>
    T read(uint64_t address) {
        T buffer{};
        read_physical((PVOID)address, &buffer, sizeof(T));
        return buffer;
    }

    // Template function for writing data to memory
    template <typename T>
    T write(uint64_t address, T value) {
        write_physical((PVOID)address, &value, sizeof(T));
        return value;
    }
};

// Inline instance to access using the syntax: driver.read, driver.write, etc.
inline CDriver driver;

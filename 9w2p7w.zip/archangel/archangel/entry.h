#pragma once

#include < stdio.h >
#include < wtypes.h >
#include < algorithm >
#include < random >
#include < chrono >
#include < thread >
#include < d3d11.h >
#include < D3DX11.h >
#include < dxgi.h >
#include < string >
#include < filesystem >
#include < fstream >
#include < tlhelp32.h >
#include < list >
#include < unordered_map >
#include < cstdint >
#include < iomanip >
#include < iostream >
#include < cmath >

#include "kernel/driver.h"

#include "setup/utils/utils.h"
#include "setup/imgui/imgui.h"
#include "setup/imgui/imgui_impl_dx11.h"
#include "setup/imgui/imgui_impl_win32.h"
#include "setup/render/drawing/drawing.h"
#include "setup/render/drawing/image.h"
#include "setup/render/overlay.h"

#include "globals/globals.h"
#include "globals/roblox.h"
#include <unordered_set>

#define _sleep_for( ms ) std::this_thread::sleep_for( std::chrono::milliseconds( ms ) );
#define roblox_process "RobloxPlayerBeta.exe"
#define return_null( ) return 0;
#define return_false( ) return false;

#define M_PI   3.14159265358979323846264338327950288

inline ID3D11Device* dx_device = nullptr;

inline ImFont* verdanaFont;
inline ImFont* pixelFont;
inline ImFont* menuSmallFont;
inline ImFont* menuBigFont;

inline std::unordered_set<uintptr_t> flagged_instances;

namespace vars
{
    namespace aimbot
    {
        inline bool aimbot_enabled = true;
        inline bool prediction = false;
        inline auto aimbot_prediction_key = VK_XBUTTON1;
        inline int aimbot_prediction_mode = 0;
        inline float prediction_factor = 0.155;
        inline bool team_check = false;
        inline bool fov_circle = false;
        inline bool auto_hitbox_select = false;
        inline bool lock_on_target = true;
        inline float fov_value = 100.0f;
        inline auto aimbot_key = VK_SHIFT;
        inline int aimbot_mode = 0;
        inline float aimbot_smoothing = 5.f;
        inline float max_distance = 800.f;
        inline int target_hitbox = 0;
        inline int aimbot_method = 0;

        namespace circle_target {
            inline bool enabled = false;
            inline bool teleport_back = true;
            inline float speed = 10.0f;
            inline float radius = 15.0f;
            inline float height_offset = 1.0f;
        }
    }

    namespace esp
    {
        inline bool esp_enabled = true;
        inline bool esp_local = false;
        inline float esp_max_distance = 1000.0f;
        inline bool team_check = false;
        inline bool esp_box = true;
        inline bool esp_skeleton = false;
        inline bool esp_fill_box = true;
        inline bool esp_name = true;
        inline bool esp_health_bar = true;
        inline bool esp_health_text = true;
        inline bool esp_distance = true;
        inline bool esp_mode = 0;
        inline ImColor name_color = ImColor(255, 255, 255, 255);
        inline ImColor box_color = ImColor(255, 133, 133, 255);        
        inline ImColor fill_box_color = ImColor(255, 133, 133, 100); 
        inline ImColor skeleton_color = ImColor(255, 255, 255, 255); 
        inline ImColor health_bar_color = ImColor(0, 255, 0, 255);    

        namespace instances
        {
            inline bool esp_box = true;
            inline bool esp_filled_box = true;
            inline bool esp_name = true;
            inline bool esp_health_bar = true;
            inline bool esp_health_number = true;
            inline bool esp_distance = true;
            inline ImColor esp_part_color = ImColor(255, 255, 255, 255);
            inline ImColor esp_model_color = ImColor(0, 255, 0, 255);
            inline ImColor esp_npc_color = ImColor(3, 140, 252, 255);
        }
    }

    namespace visuals
    {
        inline ImColor fov_circle_color = ImColor(255, 255, 255, 255); 
    }

    namespace misc
    {
        inline bool teleport_to_nearest = false;
        inline auto teleport_key = VK_XBUTTON1;
        inline bool teleport_arrow = false;
        inline ImColor teleport_arrow_color = ImColor(209, 112, 250, 255);

        inline bool noclip_enabled = false;
        inline int noclip_mode = 0;
        inline auto noclip_key = VK_TAB;
    }

    namespace instance_explorer
    {
        inline bool enabled = false;
        inline float cache_time = 2.f;
    }
}

inline ID3D11ShaderResourceView* workspace_image = nullptr;
inline ID3D11ShaderResourceView* part_image = nullptr;
inline ID3D11ShaderResourceView* model_image = nullptr;
inline ID3D11ShaderResourceView* camera_image = nullptr;
inline ID3D11ShaderResourceView* folder_image = nullptr;
inline ID3D11ShaderResourceView* local_script_image = nullptr;
inline ID3D11ShaderResourceView* script_image = nullptr;
inline ID3D11ShaderResourceView* humanoid_image = nullptr;
inline ID3D11ShaderResourceView* players_image = nullptr;
inline ID3D11ShaderResourceView* sound_image = nullptr;
inline ID3D11ShaderResourceView* accessory_image = nullptr;
inline ID3D11ShaderResourceView* hat_image = nullptr;
inline ID3D11ShaderResourceView* player_image = nullptr;
inline ID3D11ShaderResourceView* module_script_image = nullptr;
inline ID3D11ShaderResourceView* replicated_storage_image = nullptr;
inline ID3D11ShaderResourceView* run_service_image = nullptr;
inline ID3D11ShaderResourceView* spawn_location_image = nullptr;
inline ID3D11ShaderResourceView* replicated_first_image = nullptr;
inline ID3D11ShaderResourceView* starter_gui_image = nullptr;
inline ID3D11ShaderResourceView* starter_pack_image = nullptr;
inline ID3D11ShaderResourceView* starter_player_image = nullptr;
inline ID3D11ShaderResourceView* stats_image = nullptr;
inline ID3D11ShaderResourceView* chat_image = nullptr;
inline ID3D11ShaderResourceView* core_gui_image = nullptr;
inline ID3D11ShaderResourceView* gui_service_image = nullptr;
inline ID3D11ShaderResourceView* aim_image = nullptr;
inline ID3D11ShaderResourceView* visuals_image = nullptr;
inline ID3D11ShaderResourceView* misc_image = nullptr;
inline ID3D11ShaderResourceView* players_menu_image = nullptr;
inline ID3D11ShaderResourceView* config_image = nullptr;
inline ID3D11ShaderResourceView* lua_image = nullptr;
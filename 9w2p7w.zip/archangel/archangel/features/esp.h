#pragma once

#include "../entry.h"

class CESP {
public:
	bool draw_players(matrix viewmatrix);
	bool draw_instances(matrix viewmatrix);
};

namespace fs { inline CESP esp; }


#include "misc.h"

void CMisc::teleport_to_nearest(matrix viewmatrix)
{
    if (!vars::misc::teleport_to_nearest)
        return;

    POINT cursor;
    if (!GetCursorPos(&cursor))
        return;

    std::vector<uintptr_t> player_instances = utils::get_players(globals::datamodel);

    uintptr_t closest_target = 0;
    float best_distance = FLT_MAX;

    for (auto& player_instance : player_instances)
    {
        if (!player_instance || player_instance == globals::local_player)
            continue;

        auto character = utils::get_model_instance(player_instance);
        if (!character)
            continue;

        uintptr_t targetPrimitive = 0;
        auto headBone = utils::find_first_child(character, "Head");
        if (headBone)
            targetPrimitive = driver.read<uintptr_t>(headBone + 0x168);
        if (!targetPrimitive)
        {
            auto rootBone = utils::find_first_child(character, "HumanoidRootPart");
            if (rootBone)
                targetPrimitive = driver.read<uintptr_t>(rootBone + 0x168);
        }
        if (!targetPrimitive)
            continue;

        Vector partPos = driver.read<Vector>(targetPrimitive + 0x140);
        Vector2D screenPos;
        if (!utils::world_to_screen(partPos, screenPos, viewmatrix, 1920, 1080))
            continue;

        float dx = static_cast<float>(cursor.x) - screenPos.x;
        float dy = static_cast<float>(cursor.y) - screenPos.y;
        float distance = sqrtf(dx * dx + dy * dy);

        if (distance < best_distance)
        {
            best_distance = distance;
            closest_target = player_instance;
            globals::teleport_target = player_instance;
        }
    }

    if (closest_target)
    {
        auto character = utils::get_model_instance(closest_target);
        if (!character)
            return;

        uintptr_t chosen_part = utils::find_first_child(character, "Head");
        if (!chosen_part) return;

        static bool xButtonPressed = false;

        if (GetAsyncKeyState(vars::misc::teleport_key) & 0x8000)
        {
            if (!xButtonPressed)
            {
                utils::console_print_color(__FILE__, "CMISC::TELEPORT_TO_NEAREST call");
                utils::teleport_to_part(globals::local_player, chosen_part);
                xButtonPressed = true;
            }
        }
        else
        {
            xButtonPressed = false;
        }
    }
}

void CMisc::test_function() 
{
    return;
}

void CMisc::noclip ( )
{
    if ( !globals::local_player )
        return;
    
    if ( !vars::misc::noclip_enabled )
        return;

    static bool noclip_toggled = false;
    bool should_noclip = false;
    
    if ( vars::misc::noclip_mode == 0 )
    {
        should_noclip = GetAsyncKeyState( vars::misc::noclip_key );
    }

    else if ( vars::misc::noclip_mode == 1 )
    {
        if ( GetAsyncKeyState ( vars::misc::noclip_key ) & 0x1 )
        {
            noclip_toggled = !noclip_toggled;
        }
        should_noclip = noclip_toggled;
    }
    
    globals::key_info::noclip_active = should_noclip;
    
    uintptr_t character = utils::get_model_instance ( globals::local_player );
    if ( !character )
        return;
    
    std::vector< std::string > targetNames;
    if ( utils::find_first_child ( character, "Torso" ) )
    {
        targetNames = { "Head", "HumanoidRootPart", "Torso" };
    }
    else if ( utils::find_first_child ( character, "UpperTorso" ) )
    {
        targetNames = { "Head", "HumanoidRootPart", "UpperTorso", "LowerTorso" };
    }
    else
    {
        targetNames = { "Head", "HumanoidRootPart", "Torso" };
    }
    
    for ( const auto & partName : targetNames )
    {
        uintptr_t child_instance = utils::find_first_child ( character, partName );
        if ( child_instance )
        {
            std::string classname = utils::get_instance_classname ( child_instance );
            if ( classname == "Part" || classname == "MeshPart" )
            {
                uint64_t part_primitive = driver.read< uintptr_t > ( child_instance + 0x168 );
                driver.write< bool > ( part_primitive + 0x313, !should_noclip );
            }
        }
    }
}
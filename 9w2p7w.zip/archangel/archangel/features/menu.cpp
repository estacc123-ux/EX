﻿#include "menu.h"
#include "../setup/imgui/imgui_internal.h"
static ImVec2 watermark_pos(10, 10);
static bool is_dragging = false;
static ImVec2 drag_offset(0, 0);

void CMenu::draw_watermark()
{
    static float fps = 0.0f;
    static float smoothing = 0.1f;
    fps = ImLerp(fps, ImGui::GetIO().Framerate, ImGui::GetIO().DeltaTime * (1.0f - smoothing));

    char watermark_text[64];
    sprintf_s(watermark_text, "Archangel - %d fps - ", static_cast<int>(fps));

    ImDrawList* draw_list = ImGui::GetForegroundDrawList();
    ImVec2 text_size = ImGui::CalcTextSize(watermark_text);
    ImVec2 beta_text_size = ImGui::CalcTextSize("Beta Build");

    const float padding_x = 10.0f;
    const float padding_y = 6.0f;
    ImVec2 rect_min = watermark_pos;
    ImVec2 rect_max = ImVec2(
        watermark_pos.x + text_size.x + beta_text_size.x + (padding_x * 2),
        watermark_pos.y + text_size.y + (padding_y * 2)
    );
    const float rounding = 10.0f;

    ImVec2 mouse_pos = ImGui::GetMousePos();
    ImRect drag_rect(rect_min, rect_max);

    if (ImGui::IsMouseClicked(0) && drag_rect.Contains(mouse_pos))
    {
        is_dragging = true;
        drag_offset = ImVec2(watermark_pos.x - mouse_pos.x, watermark_pos.y - mouse_pos.y);
    }

    if (is_dragging)
    {
        if (ImGui::IsMouseDown(0))
        {
            watermark_pos = ImVec2(mouse_pos.x + drag_offset.x, mouse_pos.y + drag_offset.y);
            rect_min = watermark_pos;
            rect_max = ImVec2(
                watermark_pos.x + text_size.x + beta_text_size.x + (padding_x * 2),
                watermark_pos.y + text_size.y + (padding_y * 2)
            );
        }
        else
        {
            is_dragging = false;
        }
    }

    const int shadow_layers = 8;
    const float shadow_offset = 2.0f;
    const float shadow_opacity = 0.06f;
    const float shadow_rounding = rounding;

    for (int i = 0; i < shadow_layers; i++)
    {
        float alpha = shadow_opacity * (1.0f - (float)i / shadow_layers);
        ImVec4 shadow_color = ImVec4(0.0f, 0.0f, 0.0f, alpha);

        draw_list->AddRectFilled(
            ImVec2(rect_min.x - shadow_offset + i, rect_min.y - shadow_offset + i),
            ImVec2(rect_max.x + shadow_offset - i, rect_max.y + shadow_offset - i),
            ImGui::GetColorU32(shadow_color),
            shadow_rounding
        );
    }

    draw_list->AddRectFilled(
        rect_min,
        rect_max,
        ImGui::GetColorU32(ImVec4(0.078f, 0.078f, 0.078f, 1.00f)), // RGB(20, 20, 20) for fill
        rounding
    );

    draw_list->AddRect(
        rect_min,
        rect_max,
        ImGui::GetColorU32(ImVec4(0.118f, 0.118f, 0.118f, 1.00f)), // RGB(30, 30, 30) for border
        rounding,
        0,
        1.0f
    );


    ImVec2 text_pos = ImVec2(watermark_pos.x + padding_x, watermark_pos.y + padding_y);
    draw_list->AddText(
        text_pos,
        ImGui::GetColorU32(ImVec4(0.85f, 0.85f, 0.85f, 1.0f)),
        watermark_text
    );

    draw_list->AddText(
        ImVec2(text_pos.x + text_size.x, text_pos.y),
        ImColor(82, 131, 255),
        "Beta Build"
    );
}

void CMenu::draw_keybinds( ) 
{
    ImDrawList* draw_list = ImGui::GetForegroundDrawList( );
    
    static ImVec2 keybind_list_pos ( 15, 500 );
    static bool keybind_dragging = false;
    static ImVec2 keybind_drag_offset ( 0, 0 );
    
    const float padding = 11.0f;
    const float rowSpacing = 4.0f;
    const char * spacing_str = "  ";
    ImVec2 spacingSize = ImGui::CalcTextSize ( spacing_str );
    float spacing = spacingSize.x;
    
    const char * modeText1 = ( vars::aimbot::aimbot_mode == 0 ) ? "Hold" : "Toggle";
    const char * labelText1 = "Aimbot";
    const char * statusText1 = ( globals::key_info::aimbot_active ) ? "Active" : "Inactive";
    
    const char * modeText2 = ( vars::aimbot::aimbot_prediction_mode == 0 ) ? "Hold" : "Toggle";
    const char * labelText2 = "Prediction";
    const char * statusText2 = ( globals::key_info::aimbot_prediction_active ) ? "Active" : "Inactive";
    
    const char * noclipModeText = ( vars::misc::noclip_mode == 0 ) ? "Hold" : "Toggle";
    const char * noclipLabelText = "No-clip";
    const char * noclipStatusText = ( globals::key_info::noclip_active ) ? "Active" : "Inactive";
    
    ImVec2 modeText1Size = ImGui::CalcTextSize ( modeText1 );
    ImVec2 modeText2Size = ImGui::CalcTextSize ( modeText2 );
    ImVec2 noclipModeTextSize = ImGui::CalcTextSize ( noclipModeText );
    float colModeWidth = ImMax ( ImMax ( modeText1Size.x, modeText2Size.x ), noclipModeTextSize.x );
    
    ImVec2 labelText1Size = ImGui::CalcTextSize ( labelText1 );
    ImVec2 labelText2Size = ImGui::CalcTextSize ( labelText2 );
    ImVec2 noclipLabelTextSize = ImGui::CalcTextSize ( noclipLabelText );
    float colLabelWidth = ImMax ( ImMax ( labelText1Size.x, labelText2Size.x ), noclipLabelTextSize.x );
    
    ImVec2 statusText1Size = ImGui::CalcTextSize ( statusText1 );
    ImVec2 statusText2Size = ImGui::CalcTextSize ( statusText2 );
    ImVec2 noclipStatusTextSize = ImGui::CalcTextSize ( noclipStatusText );
    float colStatusWidth = ImMax ( ImMax ( statusText1Size.x, statusText2Size.x ), noclipStatusTextSize.x );
    
    float panelWidth = padding * 2 + colModeWidth + spacing + colLabelWidth + spacing + colStatusWidth;
    
    const char * headerText = "Keybind List";
    ImVec2 headerTextSize = ImGui::CalcTextSize ( headerText );
    float headerPadding = 4.0f;
    float separatorHeight = 1.0f;
    float headerAreaHeight = headerTextSize.y + headerPadding + separatorHeight;
    
    float baseTextHeight = ImGui::CalcTextSize ( "A" ).y;
    float rowHeight = baseTextHeight + 6.0f;
    const int rowCount = 3;
    
    float extraSpace = 4.0f;
    
    float panelHeight = padding * 2 + headerAreaHeight + extraSpace + rowCount * rowHeight + ( rowCount - 1 ) * rowSpacing;
    
    ImVec2 mousePos = ImGui::GetMousePos ();
    ImRect headerRect ( keybind_list_pos, ImVec2 ( keybind_list_pos.x + panelWidth, keybind_list_pos.y + headerTextSize.y + headerPadding ) );
    if ( ImGui::IsMouseClicked ( 0 ) && headerRect.Contains ( mousePos ) ) {
        keybind_dragging = true;
        keybind_drag_offset = ImVec2 ( keybind_list_pos.x - mousePos.x, keybind_list_pos.y - mousePos.y );
    }
    if ( keybind_dragging ) {
        if ( ImGui::IsMouseDown ( 0 ) ) {
            keybind_list_pos = ImVec2 ( mousePos.x + keybind_drag_offset.x, mousePos.y + keybind_drag_offset.y );
        } else {
            keybind_dragging = false;
        }
    }
    ImVec2 pos = keybind_list_pos;
    
    const int shadow_layers = 4;
    const float shadow_offset = 2.0f;
    const float shadow_opacity = 0.1f;
    for ( int i = 0; i < shadow_layers; i++ ) {
        float alpha = shadow_opacity * ( 1.0f - ( float ) i / shadow_layers );
        ImVec4 shadowColor ( 0.0f, 0.0f, 0.0f, alpha );
        draw_list->AddRectFilled (
            ImVec2 ( pos.x - shadow_offset + i, pos.y - shadow_offset + i ),
            ImVec2 ( pos.x + panelWidth + shadow_offset - i, pos.y + panelHeight + shadow_offset - i ),
            ImGui::GetColorU32 ( shadowColor )
        );
    }
    
    ImVec4 panelColor ( 0.078f, 0.078f, 0.078f, 1.0f );
    ImVec4 borderColor ( 0.118f, 0.118f, 0.118f, 1.0f );
    const float rounding = 8.0f;
    draw_list->AddRectFilled ( pos, ImVec2 ( pos.x + panelWidth, pos.y + panelHeight ), ImGui::GetColorU32 ( panelColor ), rounding );
    draw_list->AddRect ( pos, ImVec2 ( pos.x + panelWidth, pos.y + panelHeight ), ImGui::GetColorU32 ( borderColor ), rounding, 0, 1.0f );
    
    ImVec2 headerPos = ImVec2 ( pos.x + padding, pos.y + padding );
    draw_list->AddText ( headerPos, ImGui::GetColorU32 ( ImVec4 ( 0.85f, 0.85f, 0.85f, 1.0f ) ), headerText );
    
    float lineY = pos.y + padding + headerTextSize.y + headerPadding;
    draw_list->AddLine ( ImVec2 ( pos.x + padding, lineY ), ImVec2 ( pos.x + panelWidth - padding, lineY ), ImGui::GetColorU32 ( ImVec4 ( 0.4f, 0.4f, 0.4f, 1.0f ) ) );
    
    float baseY = pos.y + padding + headerAreaHeight + extraSpace;
    
    float col1X = pos.x + padding;
    float col2X = col1X + colModeWidth + spacing;
    float col3X = col2X + colLabelWidth + spacing;
    
    ImU32 defaultColor = ImGui::GetColorU32 ( ImVec4 ( 0.85f, 0.85f, 0.85f, 1.0f ) );
    ImU32 activeColor = ImGui::GetColorU32 ( ImVec4 ( 71 / 255.f, 139 / 255.f, 255 / 255.f, 1.0f ) );
    ImU32 inactiveColor = ImGui::GetColorU32 ( ImVec4 ( 0.5f, 0.5f, 0.5f, 1.0f ) );
    
    float row1Y = baseY;
    draw_list->AddText ( ImVec2 ( col1X, row1Y ), defaultColor, modeText1 );
    draw_list->AddText ( ImVec2 ( col2X, row1Y ), defaultColor, labelText1 );
    ImU32 statusColor1 = globals::key_info::aimbot_active ? activeColor : inactiveColor;
    draw_list->AddText ( ImVec2 ( col3X, row1Y ), statusColor1, statusText1 );
    
    float row2Y = baseY + rowHeight + rowSpacing;
    draw_list->AddText ( ImVec2 ( col1X, row2Y ), defaultColor, modeText2 );
    draw_list->AddText ( ImVec2 ( col2X, row2Y ), defaultColor, labelText2 );
    ImU32 statusColor2 = globals::key_info::aimbot_prediction_active ? activeColor : inactiveColor;
    draw_list->AddText ( ImVec2 ( col3X, row2Y ), statusColor2, statusText2 );
    
    float row3Y = baseY + 2 * rowHeight + 2 * rowSpacing;
    draw_list->AddText ( ImVec2 ( col1X, row3Y ), defaultColor, noclipModeText );
    draw_list->AddText ( ImVec2 ( col2X, row3Y ), defaultColor, noclipLabelText );
    ImU32 statusColor3 = globals::key_info::noclip_active ? activeColor : inactiveColor;
    draw_list->AddText ( ImVec2 ( col3X, row3Y ), statusColor3, noclipStatusText );
}


void CustomIconButton(const char* label, ImTextureID icon, ImVec2 size, bool& selected) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    const float icon_size = 21;    
    const float spacing = 8;       
    const float padding_left = 10; 

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size_arg = size;

    ImRect bb(pos, ImVec2(pos.x + size_arg.x, pos.y + size_arg.y));
    ImGui::ItemSize(bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(bb, id))
        return;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);
    if (pressed)
        selected = true;

    ImGui::RenderNavHighlight(bb, id);
    ImGui::RenderFrame(bb.Min, bb.Max, ImGui::GetColorU32(selected ? ImGuiCol_ButtonActive : (hovered ? ImGuiCol_ButtonHovered : ImGuiCol_Button)), true, style.FrameRounding);

    float icon_x = bb.Min.x + padding_left;
    float text_x = icon_x + icon_size + spacing;

    ImVec2 icon_pos(icon_x, bb.Min.y + (size_arg.y - icon_size) * 0.5f);
    window->DrawList->AddImage(icon, icon_pos, ImVec2(icon_pos.x + icon_size, icon_pos.y + icon_size));

    ImVec2 text_pos(text_x, bb.Min.y + (size_arg.y - label_size.y) * 0.5f);
    ImGui::RenderText(text_pos, label);
}

bool CMenu::draw_menu( )
{
    static ImVec2 display_size = ImGui::GetIO( ).DisplaySize;
    static ImVec2 menu_size( 800, 550 );
    static ImVec2 menu_pos( ( display_size.x - menu_size.x ) / 2, ( display_size.y - menu_size.y ) / 2 );

    static float menu_alpha = 0.0f;
    menu_alpha = ImLerp( menu_alpha, 1.0f, ImGui::GetIO( ).DeltaTime * 4.0f );

    ImGui::SetNextWindowSize( menu_size );
    ImGui::SetNextWindowPos( menu_pos, ImGuiCond_Once );

    ImGui::PushStyleVar( ImGuiStyleVar_Alpha, menu_alpha );

    ImGui::Begin( "Archangel", nullptr,
        ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoTitleBar );

    ImVec2 window_pos = ImGui::GetWindowPos( );

    ImDrawList* draw_list = ImGui::GetBackgroundDrawList( );
    const int shadow_layers = 15;
    const float shadow_offset = 8.0f;
    const float shadow_opacity = 0.06f;
    const float shadow_rounding = 12.0f;

    for ( int i = 0; i < shadow_layers; i++ )
    {
        float alpha = shadow_opacity * ( 1.0f - ( float ) i / shadow_layers ) * menu_alpha;
        ImVec4 shadow_color = ImVec4( 0.0f, 0.0f, 0.0f, alpha );

        draw_list->AddRectFilled(
            ImVec2( window_pos.x - shadow_offset + i, window_pos.y - shadow_offset + i ),
            ImVec2( window_pos.x + menu_size.x + shadow_offset - i, window_pos.y + menu_size.y + shadow_offset - i ),
            ImGui::GetColorU32( shadow_color ),
            shadow_rounding
        );
    }

    float window_width = ImGui::GetWindowWidth( );

    ImGui::PushStyleColor( ImGuiCol_Text, ImVec4( 0.85f, 0.85f, 0.85f, menu_alpha ) );
    ImGui::Text( "Archangel" );
    ImGui::PopStyleColor( );
    ImGui::Separator( );

    ImGui::BeginChild( "Sidebar", ImVec2( 130, menu_size.y - 45 ), true );
    const char* sidebar_items[] = { "Aimbot", "Visuals", "Misc", "Players", "Config", "Scripting" };

    ImTextureID tab_icons[] = {
        ImTextureID( aim_image ),
        ImTextureID( visuals_image ),
        ImTextureID( misc_image ),
        ImTextureID( players_menu_image ),
        ImTextureID( config_image ),
        ImTextureID( lua_image )
    };

    static int selected_tab = 0;
    for ( int i = 0; i < IM_ARRAYSIZE( sidebar_items ); i++ )
    {
        bool is_selected = ( selected_tab == i );

        static ImVec4 accent = ImVec4( 0.078f, 0.078f, 0.078f, 1.00f );  // RGB(20, 20, 20)
        static ImVec4 base = ImVec4( 0.098f, 0.098f, 0.098f, 1.00f );    // RGB(25, 25, 25)

        static float selections[5] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
        selections[i] = ImLerp( selections[i], is_selected ? 1.0f : 0.0f, ImGui::GetIO( ).DeltaTime * 8.0f );

        ImGui::PushStyleColor( ImGuiCol_Button,
            ImVec4(
                ImLerp( base.x, accent.x, selections[i] ),
                ImLerp( base.y, accent.y, selections[i] ),
                ImLerp( base.z, accent.z, selections[i] ),
                ImLerp( 0.7f, 1.0f, selections[i] )
            )
        );

        ImGui::PushStyleColor( ImGuiCol_Text,
            ImVec4(
                ImLerp( 0.70f, 1.0f, selections[i] ),
                ImLerp( 0.70f, 1.0f, selections[i] ),
                ImLerp( 0.70f, 1.0f, selections[i] ),
                1.00f
            )
        );

        ImGui::PushID( i );

        bool tab_selected = ( selected_tab == i );
        CustomIconButton( sidebar_items[i], tab_icons[i], ImVec2( 120, 30 ), tab_selected );
        if ( tab_selected )
        {
            selected_tab = i;
        }

        ImGui::PopID( );
        ImGui::PopStyleColor( 2 );
        ImGui::Spacing( );
    }
    ImGui::EndChild( );
    ImGui::SameLine( );

    const float content_width = menu_size.x - 150;
    ImGui::BeginChild( "Content", ImVec2( content_width, menu_size.y - 45 ), true );

    if ( selected_tab == 0 )
    {
        ImGui::BeginChild( "Aimbot", ImVec2( content_width * 0.485f, 0 ), true );
        ImGui::Text( "Global Settings" );
        ImGui::Separator( );
        ImGui::Spacing( );

        ImGui::Checkbox( "Aimbot Enabled", &vars::aimbot::aimbot_enabled );
        g::drawing.hotkey( "Key", &vars::aimbot::aimbot_key, &vars::aimbot::aimbot_mode, ImVec2( 80, 23 ) );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "FOV", &vars::aimbot::fov_value, 20, 1000, "%.1f" );
        const char* aimbot_options[] = { "Mouse", "Camera" };
        ImGui::Combo( "Aimbot Method", &vars::aimbot::aimbot_method, aimbot_options, IM_ARRAYSIZE( aimbot_options ) );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Max Distance", &vars::aimbot::max_distance, 5, 10000, "%.f" );
        ImGui::PopItemWidth( );

        ImGui::Spacing( );
        ImGui::Text( "Aimbot Targets" );
        const char* hitbox_options[ ] = { "Head", "Body" };
        ImGui::Combo( "Target Hitbox", &vars::aimbot::target_hitbox, hitbox_options, IM_ARRAYSIZE( hitbox_options ) );
        ImGui::Spacing( );
        ImGui::Text( "Player Settings" );
        ImGui::Checkbox( "Auto-Hitbox Selection", &vars::aimbot::auto_hitbox_select );
        ImGui::Text( "Rage (Risk)" );
        ImGui::Checkbox( "Circle Target", &vars::aimbot::circle_target::enabled );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Speed", &vars::aimbot::circle_target::speed, 1, 15, "%.1f" );
        ImGui::SliderFloat( "Radius", &vars::aimbot::circle_target::radius, 1, 20, "%.1f" );
        ImGui::SliderFloat( "Height Offset", &vars::aimbot::circle_target::height_offset, 1, 20, "%.1f" );
        ImGui::PushItemWidth( 135 );
        ImGui::Checkbox( "Teleport Back", &vars::aimbot::circle_target::teleport_back );

        ImGui::EndChild( );

        ImGui::SameLine( );
        ImGui::BeginChild( "Additional", ImVec2( content_width * 0.485f, 0 ), true );
        ImGui::Text( "Additional Settings" );
        ImGui::Separator( );
        ImGui::Spacing( );

        ImGui::Checkbox( "Lock Target", &vars::aimbot::lock_on_target );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Smoothing Factor", &vars::aimbot::aimbot_smoothing, 0, 15, "%.3f" );
        ImGui::PopItemWidth( );

        ImGui::Spacing( );
        ImGui::Text( "Player Settings" );
        ImGui::Checkbox( "Team-check", &vars::aimbot::team_check );

        ImGui::Spacing( );
        ImGui::Text( "Experimental" );
        ImGui::Checkbox( "Prediction", &vars::aimbot::prediction );
        g::drawing.hotkey( "Prediction Key", &vars::aimbot::aimbot_prediction_key, &vars::aimbot::aimbot_prediction_mode, ImVec2( 80, 23 ) );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Prediction Factor", &vars::aimbot::prediction_factor, 0.00, 2, "%.3f" );
        ImGui::PopItemWidth( );

        ImGui::EndChild( );
    }

    if ( selected_tab == 1 )
    {
        ImGui::BeginChild( "Visuals", ImVec2( content_width * 0.485f, 0 ), true );
        ImGui::Text( "ESP Settings" );
        ImGui::Separator( );
        ImGui::Spacing( );

        ImGui::Checkbox( "ESP Enabled", &vars::esp::esp_enabled );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Max Distance", &vars::esp::esp_max_distance, 5, 10000, "%.f" );
        ImGui::PopItemWidth( );

        ImGui::Spacing( );
        ImGui::Text( "Players" );

        if ( ImGui::BeginCombo( "Elements", "Options" ) )
        {
            ImGui::Checkbox( "Name", &vars::esp::esp_name );
            ImGui::SameLine( );
            ImGui::ColorEdit4( "##NameColor", ( float* )&vars::esp::name_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

            ImGui::Checkbox( "Box", &vars::esp::esp_box );
            ImGui::SameLine( );
            ImGui::ColorEdit4( "##BoxColor", ( float* )&vars::esp::box_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

            ImGui::Checkbox( "Filled Box", &vars::esp::esp_fill_box );
            ImGui::SameLine( );
            ImGui::ColorEdit4( "##FilledBoxColor", ( float* )&vars::esp::fill_box_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

            ImGui::Checkbox( "Health Bar", &vars::esp::esp_health_bar );
            ImGui::SameLine( );
            ImGui::ColorEdit4( "##HealthBarColor", ( float* )&vars::esp::health_bar_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

            ImGui::Checkbox( "Health Number", &vars::esp::esp_health_text );

            ImGui::Checkbox( "Skeleton", &vars::esp::esp_skeleton );
            ImGui::SameLine( );
            ImGui::ColorEdit4( "##SkeletonColor", ( float* )&vars::esp::skeleton_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

            ImGui::Checkbox( "Distance", &vars::esp::esp_distance );

            ImGui::EndCombo( );
        }

        ImGui::Checkbox( "Box Bone Calculation", &vars::esp::esp_mode );
        ImGui::Checkbox( "Team-check", &vars::esp::team_check );
        ImGui::Checkbox( "Local", &vars::esp::esp_local );

        ImGui::Spacing( );
        ImGui::Text( "Flagged Instances" );

        if ( ImGui::BeginCombo( "Elements ", "Options" ) )
        {
            ImGui::Checkbox( "Name", &vars::esp::instances::esp_name );
            ImGui::Checkbox( "Box", &vars::esp::instances::esp_box );
            ImGui::Checkbox( "Filled Box", &vars::esp::instances::esp_filled_box );
            ImGui::Checkbox( "Health Bar", &vars::esp::instances::esp_health_bar );
            ImGui::Checkbox( "Health Number", &vars::esp::instances::esp_health_number );
            ImGui::Checkbox( "Distance", &vars::esp::instances::esp_distance );
            ImGui::ColorEdit4( "Part Color", ( float* )&vars::esp::instances::esp_part_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar );
            ImGui::ColorEdit4( "Model Color", ( float* )&vars::esp::instances::esp_model_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar );
            ImGui::ColorEdit4( "NPC Color", ( float* )&vars::esp::instances::esp_npc_color.Value,
                ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar );

            ImGui::EndCombo( );
        }

        ImGui::EndChild( );

        ImGui::SameLine( );
        ImGui::BeginChild( "Visual", ImVec2( content_width * 0.485f, 0 ), true );
        ImGui::Text( "Visual Settings" );
        ImGui::Separator( );
        ImGui::Spacing( );

        ImGui::Checkbox( "Visualize FOV Circle", &vars::aimbot::fov_circle );
        ImGui::SameLine( );
        ImGui::ColorEdit4( "##FovCircleColor", ( float* )&vars::visuals::fov_circle_color.Value,
            ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

        ImGui::EndChild( );
    }

    if ( selected_tab == 2 )
    {
        ImGui::BeginChild( "Misc", ImVec2( content_width * 0.485f, 0 ), true );
        ImGui::Text( "Misc Settings" );
        ImGui::Separator( );
        ImGui::Spacing( );

        ImGui::Checkbox( "Teleport To Nearest", &vars::misc::teleport_to_nearest );
        g::drawing.hotkey_no_modes( "Teleport Key", &vars::misc::teleport_key, ImVec2( 80, 23 ) );
        ImGui::Checkbox( "Visualize Teleport Target", &vars::misc::teleport_arrow );
        ImGui::SameLine( );
        ImGui::ColorEdit4( "##TeleportArrowColor", ( float* )&vars::misc::teleport_arrow_color.Value,
            ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaBar );

        ImGui::Spacing( );
        ImGui::Text( "Instance Explorer" );
        ImGui::Checkbox( "Enable Instance Explorer", &vars::instance_explorer::enabled );
        ImGui::PushItemWidth( 135 );
        ImGui::SliderFloat( "Instance Caching", &vars::instance_explorer::cache_time, 0, 3, "%.1f" );
        ImGui::PopItemWidth( );

        ImGui::Spacing( );
        ImGui::Text( "Player Exploits" );
        ImGui::Checkbox( "No-clip", &vars::misc::noclip_enabled );
        ImGui::SameLine( );
        g::drawing.hotkey( "Key", &vars::misc::noclip_key, &vars::misc::noclip_mode, ImVec2( 80, 23 ) );

        ImGui::EndChild( );
    }

    ImGui::EndChild( );
    ImGui::PopStyleVar( );
    ImGui::End( );

    if ( vars::instance_explorer::enabled )
    {
        draw_instance_explorer( );
    }

    return true;
}


void CMenu::draw_instance_explorer()
{
    static ImVec2 window_pos(300, 300);
    static ImVec2 window_size(400, 500);

    ImGui::SetNextWindowPos(window_pos, ImGuiCond_Once);
    ImGui::SetNextWindowSize(window_size);

    if (ImGui::Begin("##InstanceExplorer", nullptr,
        ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize ))
    {
        ImVec2 window_pos_ = ImGui::GetWindowPos();

        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        const int shadow_layers = 15;
        const float shadow_offset = 8.0f;
        const float shadow_opacity = 0.06f;
        const float shadow_rounding = 12.0f;

        for (int i = 0; i < shadow_layers; i++)
        {
            float alpha = shadow_opacity * (1.0f - (float)i / shadow_layers);
            ImVec4 shadow_color = ImVec4(0.0f, 0.0f, 0.0f, alpha);

            draw_list->AddRectFilled(
                ImVec2(window_pos_.x - shadow_offset + i, window_pos_.y - shadow_offset + i),
                ImVec2(window_pos_.x + window_size.x + shadow_offset - i, window_pos_.y + window_size.y + shadow_offset - i),
                ImGui::GetColorU32(shadow_color),
                shadow_rounding
            );
        }

        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.80f, 0.80f, 0.80f, 1.00f));
        ImGui::Text("Instance Explorer");

        ImGui::PopStyleColor();

        ImGui::Separator();
        ImGui::Spacing();

        using Clock = std::chrono::steady_clock;
        static auto lastCacheRefresh = Clock::now();
        auto now = Clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastCacheRefresh).count() > 2000) {
            cache.clear();
            lastCacheRefresh = now;
        }

        std::vector<uintptr_t> datamodel_children;
        if (cache.find(globals::datamodel) == cache.end()) {
            datamodel_children = utils::children(globals::datamodel);
            cache[globals::datamodel] = datamodel_children;
        }
        else {
            datamodel_children = cache[globals::datamodel];
        }

        for (auto& child : datamodel_children) {
            draw_instance_tree(child);
        }

        ImGui::End();
    }
}

std::unordered_map<uintptr_t, std::vector<uintptr_t>> cache;

void refreshCache() {
    using Clock = std::chrono::steady_clock;
    static auto lastCacheRefresh = Clock::now();
    auto now = Clock::now();
    if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastCacheRefresh).count() > 1000) {
        cache.clear();
        lastCacheRefresh = now;
    }
}
uintptr_t selected_instance = 0;

void CMenu::draw_instance_tree(uintptr_t instance)
{
    refreshCache();
    std::unordered_map<std::string, ID3D11ShaderResourceView*> class_icons = {
        {"Workspace", workspace_image},
        {"Part", part_image},
        {"MeshPart", part_image},
        {"Model", model_image},
        {"Camera", camera_image},
        {"Folder", folder_image},
        {"LocalScript", local_script_image},
        {"Script", script_image},
        {"Humanoid", humanoid_image},
        {"Players", players_image},
        {"Sound", sound_image},
        {"Accessory", accessory_image},
        {"Hat", hat_image},
        {"Player", player_image},
        {"ModuleScript", module_script_image},
        {"ReplicatedStorage", replicated_storage_image},
        {"RunService", run_service_image},
        {"SpawnLocation", spawn_location_image},
        {"ReplicatedFirst", replicated_first_image},
        {"StarterGui", starter_gui_image},
        {"StarterPack", starter_pack_image},
        {"StarterPlayer", starter_player_image},
        {"Stats", stats_image},
        {"Chat", chat_image},
        {"CoreGui", core_gui_image},
        {"GuiService", gui_service_image},
    };

    static uintptr_t popup_instance = 0;

    ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(0.078f, 0.078f, 0.078f, 1.00f));        // RGB(20, 20, 20)
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(0.098f, 0.098f, 0.098f, 1.00f));  // RGB(25, 25, 25)
    ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImVec4(0.118f, 0.118f, 0.118f, 1.00f));   // RGB(30, 30, 30)


    std::vector<uintptr_t> children_list;
    if (cache.find(instance) == cache.end()) {
        children_list = utils::children(instance);
        cache[instance] = children_list;
    }
    else {
        children_list = cache[instance];
    }

    std::string instance_name = utils::get_instance_name(instance);
    std::string class_name = utils::get_instance_classname(instance);
    std::string label = instance_name + "##" + std::to_string(instance);

    ID3D11ShaderResourceView* icon = nullptr;
    if (class_icons.find(class_name) != class_icons.end()) {
        icon = class_icons[class_name];
    }

    if (children_list.empty()) {
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.5f, 0.5f, 0.5f, 1.0f));
    }

    ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow;
    if (selected_instance == instance) {
        flags |= ImGuiTreeNodeFlags_Selected;
    }
    if (children_list.empty()) {
        flags |= ImGuiTreeNodeFlags_Leaf;
    }

    bool node_open = ImGui::TreeNodeEx(label.c_str(), flags);

    if (ImGui::IsItemClicked(ImGuiMouseButton_Left)) {
        selected_instance = instance;
    }

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(ImGuiMouseButton_Right)) {
        popup_instance = instance;
        ImGui::SetNextWindowPos(ImGui::GetMousePos());
        ImGui::OpenPopup("##InstancePropertiesPopup");
    }

    if (icon) {
        ImGui::SameLine();
        ImGui::Image((ImTextureID)icon, ImVec2(15, 15));
    }

    if (popup_instance == instance) {
        if (ImGui::BeginPopup("##InstancePropertiesPopup")) {
            ImGui::TextUnformatted(("Name: " + instance_name).c_str());
            ImGui::TextUnformatted(("Class: " + class_name).c_str());

            bool is_flagged = flagged_instances.contains(instance);
            if (ImGui::Checkbox("Flag", &is_flagged)) {
                if (is_flagged) {
                    flagged_instances.insert(instance);
                }
                else {
                    flagged_instances.erase(instance);
                }
            }

            if (class_name == "Part" || class_name == "MeshPart" || class_name == "SpawnLocation" || class_name == "UnionOperation") {
                if (ImGui::Button("Teleport")) {
                    utils::teleport_to_part(globals::local_player, instance);
                }
            }

            if (class_name == "ProximityPrompt") 
            {
                uintptr_t holdDurations = driver.read<uintptr_t>(instance + 0x168);
                static float holdDuration = driver.read<float>(instance + 0x128);

                if (ImGui::SliderFloat("Hold Duration", &holdDuration, 0.0f, 10.0f)) {
                    driver.write<float>(instance + 0x128, holdDuration);
                }

            }

            ImGui::EndPopup();
        }
    }

    if (node_open) {
        for (auto& child_address : children_list) {
            draw_instance_tree(child_address);
        }
        ImGui::TreePop();
    }

    if (children_list.empty()) {
        ImGui::PopStyleColor();
    }

    ImGui::PopStyleColor(3);
}

#pragma once

#include "../entry.h"

class CImageHandler {
public:
	void create_images();
	void release_images();
};

inline CImageHandler image_handler;


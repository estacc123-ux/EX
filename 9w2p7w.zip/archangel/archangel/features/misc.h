#pragma once

#include "../entry.h"

class CMisc {
public:
	void teleport_to_nearest(matrix viewmatrix);
	void fix_position();
	void test_function();
	void noclip();
};

namespace fs { inline CMisc misc; }


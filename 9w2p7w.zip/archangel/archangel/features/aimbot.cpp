#include "aimbot.h"

bool CAimbot::circle_target()
{
    auto local_character = utils::get_model_instance(globals::local_player);
    if (!local_character)
        return false;

    auto local_root = utils::find_first_child(local_character, "HumanoidRootPart");
    if (!local_root)
        return false;

    uintptr_t local_primitive = driver.read<uintptr_t>(local_root + 0x168);
    if (!local_primitive)
        return false;

    static Vector original_pos;
    static bool saved_original = false;
    static bool teleport_back_done = false;
    static float angle = 0.0f;
    static auto last_time = std::chrono::steady_clock::now();

    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - last_time).count();
    last_time = now;

    if (this->locked_target)
    {
        if (vars::aimbot::circle_target::teleport_back && !saved_original)
        {
            original_pos = driver.read<Vector>(local_primitive + 0x140);
            saved_original = true;
            teleport_back_done = false;
        }

        auto target_character = utils::get_model_instance(this->locked_target);
        if (!target_character)
            return false;

        auto target_root = utils::find_first_child(target_character, "HumanoidRootPart");
        if (!target_root)
            return false;

        uintptr_t target_primitive = driver.read<uintptr_t>(target_root + 0x168);
        if (!target_primitive)
            return false;

        Vector target_pos = driver.read<Vector>(target_primitive + 0x140);

        angle += vars::aimbot::circle_target::speed * dt;
        Vector new_local_pos = target_pos;
        new_local_pos.x += vars::aimbot::circle_target::radius * std::cos(angle);
        new_local_pos.z += vars::aimbot::circle_target::radius * std::sin(angle);
        new_local_pos.y += vars::aimbot::circle_target::height_offset;

        driver.write<Vector>(local_primitive + 0x140, new_local_pos);
        return true;
    }
    else
    {
        if (vars::aimbot::circle_target::teleport_back && saved_original && !teleport_back_done)
        {
            for (int i = 0; i < 10; i++)
            {
                driver.write<Vector>(local_primitive + 0x140, original_pos);
                _sleep_for(1);
                driver.write<Vector>(local_primitive + 0x140, original_pos);
            }
            teleport_back_done = true;
            saved_original = false;
            angle = 0.0f;

            original_pos = driver.read<Vector>(local_primitive + 0x140);
        }
        return false;
    }

    utils::console_print_color(__FILE__, "circle_target active");
}


bool CAimbot::aim_at_closest_player( matrix view_matrix )
{
    static std::string locked_bone_name ;

    if ( ! vars::aimbot::aimbot_enabled )
        return false ;

    bool pred_key_pressed = ( GetAsyncKeyState( vars::aimbot::aimbot_prediction_key ) & 0x8000 ) != 0 ;
    static bool prediction_toggle_key_down = false ;

    if ( vars::aimbot::prediction )
    {
        if ( vars::aimbot::aimbot_prediction_mode == 1 )
        {
            if ( pred_key_pressed && ! prediction_toggle_key_down )
            {
                globals::key_info::aimbot_prediction_active = ! globals::key_info::aimbot_prediction_active ;
                prediction_toggle_key_down = true ;
            }
            else if ( ! pred_key_pressed )
            {
                prediction_toggle_key_down = false ;
            }
        }
        else
        {
            globals::key_info::aimbot_prediction_active = pred_key_pressed ;
        }
    }

    bool key_pressed = ( GetAsyncKeyState( vars::aimbot::aimbot_key ) & 0x8000 ) != 0 ;
    static bool toggle_key_down = false ;
    if ( vars::aimbot::aimbot_mode == 1 )
    {
        if ( key_pressed && ! toggle_key_down )
        {
            globals::key_info::aimbot_active = ! globals::key_info::aimbot_active ;
            toggle_key_down = true ;
        }
        else if ( ! key_pressed )
        {
            toggle_key_down = false ;
        }
        if ( ! globals::key_info::aimbot_active )
        {
            locked_target = 0 ;
            locked_bone_name.clear( ) ;
            return true ;
        }
    }
    else
    {
        if ( ! key_pressed )
        {
            locked_target = 0 ;
            locked_bone_name.clear( ) ;
            globals::key_info::aimbot_active = false ;
            return true ;
        }
        else
        {
            globals::key_info::aimbot_active = true ;
        }
    }

    auto local_character = utils::get_model_instance( globals::local_player ) ;
    if ( ! local_character )
        return false ;
    auto local_root = utils::find_first_child( local_character , "HumanoidRootPart" ) ;
    if ( ! local_root )
        return false ;
    uintptr_t local_primitive = driver.read< uintptr_t >( local_root + 0x168 ) ;
    if ( ! local_primitive )
        return false ;
    Vector local_pos = driver.read< Vector >( local_primitive + 0x140 ) ;

    static auto last_time = std::chrono::steady_clock::now( ) ;
    auto now = std::chrono::steady_clock::now( ) ;
    std::chrono::duration< float > elapsed = now - last_time ;
    static std::vector< uintptr_t > player_instances ;
    if ( elapsed.count( ) >= 0.5f )
    {
        last_time = now ;
        player_instances = utils::get_players( globals::datamodel ) ;
    }

    POINT cursor ;
    if ( ! GetCursorPos( & cursor ) )
        return false ;

    const char * selected_bone_name = nullptr ;

    if ( locked_target )
    {
        auto character = utils::get_model_instance( locked_target ) ;
        if ( character )
        {
            auto humanoid = utils::find_first_child_byclass( character , "Humanoid" ) ;
            if ( humanoid )
            {
                float health = driver.read< float >( humanoid + roblox::offsets::Health ) ;
                if ( health && health <= 0 )
                {
                    locked_target = 0 ;
                    locked_bone_name.clear( ) ;
                    return true ;
                }
            }
            else
            {
                locked_target = 0 ;
                locked_bone_name.clear( ) ;
                return true ;
            }
            if ( vars::aimbot::team_check && driver.read< int >( locked_target + roblox::offsets::Team ) == driver.read< int >( globals::local_player + roblox::offsets::Team ) )
            {
                locked_target = 0 ;
                locked_bone_name.clear( ) ;
            }
            else if ( vars::aimbot::auto_hitbox_select )
            {
                float candidate_distance = FLT_MAX ;
                const char * best_bone = nullptr ;
                auto head_bone = utils::find_first_child( character , "Head" ) ;
                if ( head_bone )
                {
                    auto head_primitive = driver.read< uintptr_t >( head_bone + 0x168 ) ;
                    if ( head_primitive )
                    {
                        Vector head_pos = driver.read< Vector >( head_primitive + 0x140 ) ;
                        float head_world_distance = sqrt( ( head_pos.x - local_pos.x ) * ( head_pos.x - local_pos.x ) + ( head_pos.y - local_pos.y ) * ( head_pos.y - local_pos.y ) + ( head_pos.z - local_pos.z ) * ( head_pos.z - local_pos.z ) ) ;
                        if ( head_world_distance <= vars::aimbot::max_distance )
                        {
                            Vector2D head_screen ;
                            if ( utils::world_to_screen( head_pos , head_screen , view_matrix , 1920 , 1080 ) )
                            {
                                float dx = static_cast< float >( cursor.x ) - head_screen.x ;
                                float dy = static_cast< float >( cursor.y ) - head_screen.y ;
                                candidate_distance = sqrt( dx * dx + dy * dy ) ;
                                best_bone = "Head" ;
                            }
                        }
                    }
                }
                auto root_bone = utils::find_first_child( character , "HumanoidRootPart" ) ;
                if ( root_bone )
                {
                    auto root_primitive = driver.read< uintptr_t >( root_bone + 0x168 ) ;
                    if ( root_primitive )
                    {
                        Vector root_pos = driver.read< Vector >( root_primitive + 0x140 ) ;
                        float root_world_distance = sqrt( ( root_pos.x - local_pos.x ) * ( root_pos.x - local_pos.x ) + ( root_pos.y - local_pos.y ) * ( root_pos.y - local_pos.y ) + ( root_pos.z - local_pos.z ) * ( root_pos.z - local_pos.z ) ) ;
                        if ( root_world_distance <= vars::aimbot::max_distance )
                        {
                            Vector2D root_screen ;
                            if ( utils::world_to_screen( root_pos , root_screen , view_matrix , 1920 , 1080 ) )
                            {
                                float dx = static_cast< float >( cursor.x ) - root_screen.x ;
                                float dy = static_cast< float >( cursor.y ) - root_screen.y ;
                                float root_distance = sqrt( dx * dx + dy * dy ) ;
                                if ( root_distance < candidate_distance )
                                {
                                    candidate_distance = root_distance ;
                                    best_bone = "HumanoidRootPart" ;
                                }
                            }
                        }
                    }
                }
                if ( best_bone )
                {
                    selected_bone_name = best_bone ;
                    locked_bone_name = best_bone ;
                }
                else if ( ! locked_bone_name.empty( ) )
                {
                    selected_bone_name = locked_bone_name.c_str( ) ;
                }
                else
                {
                    locked_target = 0 ;
                }
            }
            else
            {
                selected_bone_name = ( vars::aimbot::target_hitbox == 0 ) ? "Head" : "HumanoidRootPart" ;
            }
        }
        else
        {
            locked_target = 0 ;
            locked_bone_name.clear( ) ;
        }
    }

    if ( ! locked_target )
    {
        float best_distance = FLT_MAX ;
        float fov_radius = vars::aimbot::fov_value ;
        for ( auto & player_instance : player_instances )
        {
            if ( !player_instance || player_instance == globals::local_player )
                continue ;

            if (globals::local_player)
            {
                int player_team = driver.read< int >( player_instance + roblox::offsets::Team );
                int local_team = driver.read< int >( globals::local_player + roblox::offsets::Team );

                if ( player_team == local_team && vars::aimbot::team_check )
                    continue;
            }

            auto character = utils::get_model_instance( player_instance ) ;
            if ( ! character )
                continue ;
            auto humanoid = utils::find_first_child_byclass( character , "Humanoid" ) ;
            if ( humanoid )
            {
                float health = driver.read< float >( humanoid + roblox::offsets::Health ) ;
                if ( health && health <= 0 )
                    continue ;
            }
            else
            {
                continue ;
            }
            if ( vars::aimbot::auto_hitbox_select )
            {
                float candidate_distance = FLT_MAX ;
                const char * best_bone = nullptr ;
                auto head_bone = utils::find_first_child( character , "Head" ) ;
                if ( head_bone )
                {
                    auto head_primitive = driver.read< uintptr_t >( head_bone + 0x168 ) ;
                    if ( head_primitive )
                    {
                        Vector head_pos = driver.read< Vector >( head_primitive + 0x140 ) ;
                        float head_world_distance = sqrt( ( head_pos.x - local_pos.x ) * ( head_pos.x - local_pos.x ) + ( head_pos.y - local_pos.y ) * ( head_pos.y - local_pos.y ) + ( head_pos.z - local_pos.z ) * ( head_pos.z - local_pos.z ) ) ;
                        if ( head_world_distance <= vars::aimbot::max_distance )
                        {
                            Vector2D head_screen ;
                            if ( utils::world_to_screen( head_pos , head_screen , view_matrix , 1920 , 1080 ) )
                            {
                                float dx = static_cast< float >( cursor.x ) - head_screen.x ;
                                float dy = static_cast< float >( cursor.y ) - head_screen.y ;
                                candidate_distance = sqrt( dx * dx + dy * dy ) ;
                                best_bone = "Head" ;
                            }
                        }
                    }
                }
                auto root_bone = utils::find_first_child( character , "HumanoidRootPart" ) ;
                if ( root_bone )
                {
                    auto root_primitive = driver.read< uintptr_t >( root_bone + 0x168 ) ;
                    if ( root_primitive )
                    {
                        Vector root_pos = driver.read< Vector >( root_primitive + 0x140 ) ;
                        float root_world_distance = sqrt( ( root_pos.x - local_pos.x ) * ( root_pos.x - local_pos.x ) + ( root_pos.y - local_pos.y ) * ( root_pos.y - local_pos.y ) + ( root_pos.z - local_pos.z ) * ( root_pos.z - local_pos.z ) ) ;
                        if ( root_world_distance <= vars::aimbot::max_distance )
                        {
                            Vector2D root_screen ;
                            if ( utils::world_to_screen( root_pos , root_screen , view_matrix , 1920 , 1080 ) )
                            {
                                float dx = static_cast< float >( cursor.x ) - root_screen.x ;
                                float dy = static_cast< float >( cursor.y ) - root_screen.y ;
                                float root_distance = sqrt( dx * dx + dy * dy ) ;
                                if ( root_distance < candidate_distance )
                                {
                                    candidate_distance = root_distance ;
                                    best_bone = "HumanoidRootPart" ;
                                }
                            }
                        }
                    }
                }
                if ( best_bone && candidate_distance <= fov_radius && candidate_distance < best_distance )
                {
                    best_distance = candidate_distance ;
                    locked_target = player_instance ;
                    selected_bone_name = best_bone ;
                    locked_bone_name = best_bone ;
                }
            }
            else
            {
                const char * bone_name = ( vars::aimbot::target_hitbox == 0 ) ? "Head" : "HumanoidRootPart" ;
                auto target_bone = utils::find_first_child( character , bone_name ) ;
                if ( ! target_bone )
                    continue ;
                auto primitive = driver.read< uintptr_t >( target_bone + 0x168 ) ;
                if ( ! primitive )
                    continue ;
                Vector pos = driver.read< Vector >( primitive + 0x140 ) ;
                float world_distance = sqrt( ( pos.x - local_pos.x ) * ( pos.x - local_pos.x ) + ( pos.y - local_pos.y ) * ( pos.y - local_pos.y ) + ( pos.z - local_pos.z ) * ( pos.z - local_pos.z ) ) ;
                if ( world_distance > vars::aimbot::max_distance )
                    continue ;
                Vector2D screen_pos ;
                if ( ! utils::world_to_screen( pos , screen_pos , view_matrix , 1920 , 1080 ) )
                    continue ;
                float dx = static_cast< float >( cursor.x ) - screen_pos.x ;
                float dy = static_cast< float >( cursor.y ) - screen_pos.y ;
                float distance = sqrt( dx * dx + dy * dy ) ;
                if ( distance <= fov_radius && distance < best_distance )
                {
                    best_distance = distance ;
                    locked_target = player_instance ;
                    selected_bone_name = bone_name ;
                }
            }
        }
    }

    if ( locked_target )
    {
        auto character = utils::get_model_instance( locked_target ) ;
        if ( ! character )
            return false ;
        const char * bone_name = selected_bone_name ? selected_bone_name : ( ( vars::aimbot::target_hitbox == 0 ) ? "Head" : "HumanoidRootPart" ) ;
        auto target_bone = utils::find_first_child( character , bone_name ) ;
        if ( ! target_bone )
            return false ;
        auto primitive = driver.read< uintptr_t >( target_bone + 0x168 ) ;
        if ( ! primitive )
            return false ;
        Vector raw_pos = driver.read< Vector >( primitive + 0x140 ) ;
        Vector pos = raw_pos ;
        if ( globals::key_info::aimbot_prediction_active )
        {
            auto humanoid_root_part = utils::find_first_child( character , "HumanoidRootPart" ) ;
            auto h_r_p_primtive = driver.read< uintptr_t >( humanoid_root_part + 0x168 ) ;
            if ( humanoid_root_part && h_r_p_primtive )
            {
                auto velocity = driver.read< Vector >( h_r_p_primtive + 0x14C ) ;
                pos = raw_pos + velocity * vars::aimbot::prediction_factor ;
            }
        }
        Vector2D screen_pos_prediction ;
        if ( utils::world_to_screen( pos , screen_pos_prediction , view_matrix , 1920 , 1080 ) )
        {
            ImVec2 box_size( 10.0f , 10.0f ) ;
            ImVec2 top_left( screen_pos_prediction.x - box_size.x / 2 , screen_pos_prediction.y - box_size.y / 2 ) ;
            ImVec2 bottom_right( screen_pos_prediction.x + box_size.x / 2 , screen_pos_prediction.y + box_size.y / 2 ) ;
            g::drawing.outlined_box( top_left , bottom_right , ImColor( 255 , 255 , 255 ) , ImColor( 0 , 0 , 0 ) , 2.0f ) ;
        }
        Vector2D screen_pos ;
        if ( ! utils::world_to_screen( pos , screen_pos , view_matrix , 1920 , 1080 ) )
            return false ;
        if ( vars::aimbot::aimbot_method == 0 )
        {
            static auto last_mouse_aim_time = std::chrono::steady_clock::now( ) ;
            auto current_time = std::chrono::steady_clock::now( ) ;
            auto elapsed_ms = std::chrono::duration_cast< std::chrono::milliseconds >( current_time - last_mouse_aim_time ).count( ) ;
            if ( elapsed_ms >= 5 )
            {
                POINT current_cursor ;
                if ( GetCursorPos( & current_cursor ) )
                {
                    float move_x = screen_pos.x - static_cast< float >( current_cursor.x ) ;
                    float move_y = screen_pos.y - static_cast< float >( current_cursor.y ) ;
                    float smoothing = vars::aimbot::aimbot_smoothing ;
                    smoothing = max( 1.0f , smoothing ) ;
                    move_x /= smoothing ;
                    move_y /= smoothing ;
                    mouse_event( MOUSEEVENTF_MOVE , static_cast< DWORD >( move_x ) , static_cast< DWORD >( move_y ) , 0 , 0 ) ;
                }
                last_mouse_aim_time = current_time ;
            }
        }
        else if ( vars::aimbot::aimbot_method == 1 )
        {
            auto workspace = utils::find_first_child_byclass( globals::datamodel, "Workspace" );
            if ( !workspace )
                return false;

            auto camera = driver.read< uintptr_t >( workspace + 0x3F0) ;
            if ( !camera )
                return false;

            auto camera_position = driver.read< Vector >( camera + 0x104 );
            auto camera_rotation = driver.read< Matrix3 >( camera + 0xE0 );
            Matrix3 hit_matrix = utils::look_at( camera_position , pos );

            for ( int i = 0; i < 3; ++ i )
            {
                driver.write< Matrix3 >( camera + 0xE0 , hit_matrix );
            }
        }
    }

    return true ;
}


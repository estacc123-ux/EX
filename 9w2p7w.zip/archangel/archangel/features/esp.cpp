#include "esp.h"
#include < functional >

void draw_skeleton ( uintptr_t character , const matrix & view_matrix , int rig_type )
{
    struct bone_part
    {
        const char * name ;
        Vector position ;
        Vector2D screen_pos ;
        bool valid = false ;
    } ;

    auto get_part_position = [ & ] ( uintptr_t character , const char * name ) -> std::pair< Vector , bool >
    {
        if ( character == 0 )
        {
            return { Vector ( ) , false } ;
        }
        auto part = utils::find_first_child ( character , name ) ;
        if ( ! part )
        {
            return { Vector ( ) , false } ;
        }
        auto primitive = driver.read< uintptr_t > ( part + 0x168 ) ;
        if ( ! primitive )
        {
            return { Vector ( ) , false } ;
        }
        Vector pos = driver.read< Vector > ( primitive + 0x140 ) ;
        return { pos , true } ;
    } ;

    std::vector< bone_part > bones ;
    if ( rig_type == 1 )
    {
        bones = {
            { "Head" , Vector ( ) , Vector2D ( ) } ,
            { "UpperTorso" , Vector ( ) , Vector2D ( ) } ,
            { "LowerTorso" , Vector ( ) , Vector2D ( ) } ,
            { "LeftUpperArm" , Vector ( ) , Vector2D ( ) } ,
            { "LeftLowerArm" , Vector ( ) , Vector2D ( ) } ,
            { "LeftHand" , Vector ( ) , Vector2D ( ) } ,
            { "RightUpperArm" , Vector ( ) , Vector2D ( ) } ,
            { "RightLowerArm" , Vector ( ) , Vector2D ( ) } ,
            { "RightHand" , Vector ( ) , Vector2D ( ) } ,
            { "LeftUpperLeg" , Vector ( ) , Vector2D ( ) } ,
            { "LeftLowerLeg" , Vector ( ) , Vector2D ( ) } ,
            { "LeftFoot" , Vector ( ) , Vector2D ( ) } ,
            { "RightUpperLeg" , Vector ( ) , Vector2D ( ) } ,
            { "RightLowerLeg" , Vector ( ) , Vector2D ( ) } ,
            { "RightFoot" , Vector ( ) , Vector2D ( ) }
        } ;
    }
    else
    {
        bones = {
            { "Head" , Vector ( ) , Vector2D ( ) } ,
            { "Torso" , Vector ( ) , Vector2D ( ) } ,
            { "Left Arm" , Vector ( ) , Vector2D ( ) } ,
            { "Right Arm" , Vector ( ) , Vector2D ( ) } ,
            { "Left Leg" , Vector ( ) , Vector2D ( ) } ,
            { "Right Leg" , Vector ( ) , Vector2D ( ) }
        } ;
    }

    for ( auto & bone : bones )
    {
        auto [ pos , valid ] = get_part_position ( character , bone.name ) ;
        if ( valid )
        {
            bone.position = pos ;
            bone.valid = utils::world_to_screen ( bone.position , bone.screen_pos , view_matrix , 1920 , 1080 ) ;
        }
    }

    auto find_bone = [ & ] ( const char * name ) -> const bone_part *
    {
        for ( const auto & bone : bones )
        {
            if ( bone.name && ( strcmp ( bone.name , name ) == 0 ) && bone.valid )
            {
                return & bone ;
            }
        }
        return nullptr ;
    } ;

    const ImColor skeleton_color = vars::esp::skeleton_color ;
    const float line_thickness = 0.5f ;

    auto draw_bone = [ & ] ( const char * from , const char * to )
    {
        const bone_part * bone_from = find_bone ( from ) ;
        const bone_part * bone_to = find_bone ( to ) ;
        if ( bone_from && bone_to )
        {
            g::drawing.outlined_line (
                ImVec2 ( bone_from->screen_pos.x , bone_from->screen_pos.y ) ,
                ImVec2 ( bone_to->screen_pos.x , bone_to->screen_pos.y ) ,
                skeleton_color ,
                ImColor ( 0 , 0 , 0 , 255 ) ,
                line_thickness
            ) ;
        }
    } ;

    if ( rig_type == 1 )
    {
        draw_bone ( "Head" , "UpperTorso" ) ;
        draw_bone ( "UpperTorso" , "LowerTorso" ) ;

        draw_bone ( "UpperTorso" , "LeftUpperArm" ) ;
        draw_bone ( "LeftUpperArm" , "LeftLowerArm" ) ;
        draw_bone ( "LeftLowerArm" , "LeftHand" ) ;

        draw_bone ( "UpperTorso" , "RightUpperArm" ) ;
        draw_bone ( "RightUpperArm" , "RightLowerArm" ) ;
        draw_bone ( "RightLowerArm" , "RightHand" ) ;

        draw_bone ( "LowerTorso" , "LeftUpperLeg" ) ;
        draw_bone ( "LeftUpperLeg" , "LeftLowerLeg" ) ;
        draw_bone ( "LeftLowerLeg" , "LeftFoot" ) ;

        draw_bone ( "LowerTorso" , "RightUpperLeg" ) ;
        draw_bone ( "RightUpperLeg" , "RightLowerLeg" ) ;
        draw_bone ( "RightLowerLeg" , "RightFoot" ) ;
    }
    else
    {
        draw_bone ( "Head" , "Torso" ) ;
        draw_bone ( "Torso" , "Left Arm" ) ;
        draw_bone ( "Torso" , "Right Arm" ) ;
        draw_bone ( "Torso" , "Left Leg" ) ;
        draw_bone ( "Torso" , "Right Leg" ) ;
    }
}

bool CESP::draw_players ( matrix view_matrix )
{
    if ( !vars::esp::esp_enabled )
    {
        return false ;
    }

    if ( !globals::datamodel )
    {
        return false ;
    }

    static auto last_time = std::chrono::steady_clock::now ( ) ;
    auto now = std::chrono::steady_clock::now ( ) ;
    std::chrono::duration< float > elapsed = now - last_time ;
    static std::vector< uintptr_t > player_instances ;

    if ( elapsed.count ( ) >= 1.f )
    {
        last_time = now ;
        auto new_player_instances = utils::get_players ( globals::datamodel ) ;
        if ( ! new_player_instances.empty ( ) && ( player_instances != new_player_instances ) )
        {
            player_instances = new_player_instances ;
        }
    }

    struct bone_part
    {
        const char * name ;
        Vector position ;
        Vector2D screen_pos ;
        bool valid = false ;
    } ;

    auto get_part_position = [ ] ( uintptr_t character , const char * name ) -> std::pair< Vector , bool >
    {
        if ( character == 0 )
        {
            return { Vector ( ) , false } ;
        }
        auto part = utils::find_first_child ( character , name ) ;
        if ( ! part )
        {
            return { Vector ( ) , false } ;
        }
        auto primitive = driver.read< uintptr_t > ( part + 0x168 ) ;
        if ( ! primitive )
        {
            return { Vector ( ) , false } ;
        }
        Vector pos = driver.read< Vector > ( primitive + 0x140 ) ;
        return { pos , true } ;
    } ;

    auto get_rig_type = [ ] ( uintptr_t character ) -> int
    {
        if ( character == 0 )
        {
            return -1 ;
        }
        if ( utils::find_first_child ( character , "UpperTorso" ) )
        {
            return 1 ;
        }
        else if ( utils::find_first_child ( character , "Torso" ) )
        {
            return 0 ;
        }
        return -1 ;
    } ;

    for ( auto & player_instance : player_instances )
    {
        if ( player_instance == 0 )
        {
            continue ;
        }

        if ( ! vars::esp::esp_local && player_instance == globals::local_player )
        {
            continue ;
        }

        auto character = utils::get_model_instance ( player_instance ) ;
        if ( ! character )
        {
            continue ;
        }

        auto humanoid = utils::find_first_child_byclass ( character , "Humanoid" ) ;
        if ( ! humanoid )
        {
            continue ;
        }

        if ( globals::local_player )
        {
            int player_team = driver.read< int >( player_instance + roblox::offsets::Team );
            int local_team = driver.read< int >( globals::local_player + roblox::offsets::Team );

            if ( player_team == local_team && vars::esp::team_check )
                continue;
        }

        float health = driver.read< float > ( humanoid + roblox::offsets::Health ) ;
        if ( health && health <= 0.0f )
        {
            continue ;
        }

        int rig_type = get_rig_type ( character ) ;
        if ( !rig_type && rig_type == -1 )
        {
            continue ;
        }



        if ( vars::esp::esp_skeleton )
        {
            draw_skeleton ( character , view_matrix , rig_type ) ;
        }

        Vector head_pos , leg_pos ;
        Vector2D head_screen , leg_screen ;
        bool head_valid = false , leg_valid = false ;

        if ( vars::esp::esp_mode == 1 )
        {
            auto head_result = get_part_position ( character , "Head" ) ;
            if ( ! head_result.second )
            {
                continue ;
            }
            head_pos = head_result.first ;
            head_valid = utils::world_to_screen ( head_pos , head_screen , view_matrix , 1920 , 1080 ) ;

            std::pair< Vector , bool > leg_result ;
            if ( rig_type == 1 )
            {
                leg_result = get_part_position ( character , "LeftFoot" ) ;
            }
            else
            {
                leg_result = get_part_position ( character , "Left Leg" ) ;
            }
            if ( ! leg_result.second )
            {
                continue ;
            }
            leg_pos = leg_result.first ;
            leg_valid = utils::world_to_screen ( leg_pos , leg_screen , view_matrix , 1920 , 1080 ) ;
        }
        else if ( vars::esp::esp_mode == 0 )
        {
            auto head_result = get_part_position ( character , "Head" ) ;
            if ( ! head_result.second )
            {
                continue ;
            }
            head_pos = head_result.first + Vector ( 0 , 1.0f , 0 ) ;
            head_valid = utils::world_to_screen ( head_pos , head_screen , view_matrix , 1920 , 1080 ) ;

            leg_pos = head_result.first - Vector ( 0 , 5.0f , 0 ) ;
            leg_valid = utils::world_to_screen ( leg_pos , leg_screen , view_matrix , 1920 , 1080 ) ;
        }

        if ( ! head_valid || ! leg_valid )
        {
            continue ;
        }

        float box_height = leg_screen.y - head_screen.y ;
        float box_width = box_height / 2.0f ;
        if ( vars::esp::esp_mode == 0 )
        {
            box_width *= 1.35f ;
        }

        ImVec2 box_top_left ( head_screen.x - box_width / 2 , head_screen.y ) ;
        ImVec2 box_bottom_right ( head_screen.x + box_width / 2 , leg_screen.y ) ;

        if ( vars::esp::esp_fill_box )
        {
            g::drawing.filled_box ( box_top_left , box_bottom_right , vars::esp::fill_box_color ) ;
        }
        if ( vars::esp::esp_box )
        {
            g::drawing.outlined_box ( box_top_left , box_bottom_right , vars::esp::box_color , ImColor ( 0 , 0 , 0 ) , 1.0f ) ;
        }

        health = std::clamp ( health , 0.0f , 100.0f ) ;
        ImColor health_color ;
        if ( health >= 75.0f )
        {
            health_color = ImColor ( 0 , 255 , 0 ) ;
        }
        else if ( health >= 30.0f )
        {
            health_color = ImColor ( 255 , 255 , 0 ) ;
        }
        else
        {
            health_color = ImColor ( 255 , 0 , 0 ) ;
        }

        float health_bar_width = 2.2f ;
        float health_bar_height = box_height * ( health / 100.0f ) ;
        ImVec2 health_bar_bottom_left ( box_top_left.x - health_bar_width - 3.5f , box_top_left.y + box_height ) ;
        ImVec2 health_bar_top_right ( health_bar_bottom_left.x + health_bar_width , health_bar_bottom_left.y - health_bar_height ) ;

        if ( vars::esp::esp_health_bar )
        {
            g::drawing.outlined_box (
                ImVec2 ( health_bar_bottom_left.x , box_top_left.y ) ,
                ImVec2 ( health_bar_top_right.x , health_bar_bottom_left.y ) ,
                ImColor ( 0 , 0 , 0 , 255 ) ,
                ImColor ( 0 , 0 , 0 , 255 ) ,
                1.0f
            ) ;
            g::drawing.filled_box ( health_bar_top_right , health_bar_bottom_left , vars::esp::health_bar_color ) ;

            std::string health_text = std::to_string ( static_cast< int > ( health ) ) ;
            ImVec2 text_size = ImGui::CalcTextSize ( health_text.c_str ( ) ) ;
            ImVec2 health_text_pos (
                health_bar_bottom_left.x + ( health_bar_width - text_size.x ) * 0.5f ,
                health_bar_top_right.y - ( text_size.y * 0.5f )
            ) ;
            ImGui::PushFont ( pixelFont ) ;
            if ( vars::esp::esp_health_text && static_cast< int > ( health ) != 100 )
            {
                g::drawing.text ( health_text , health_text_pos , ImColor ( 255 , 255 , 255 ) ) ;
            }
            ImGui::PopFont ( ) ;
        }

        if ( vars::esp::esp_name )
        {
            std::string player_name = utils::get_instance_name ( player_instance ) ;
            if ( ! player_name.empty ( ) )
            {
                ImGui::PushFont ( verdanaFont ) ;
                ImVec2 text_size = ImGui::CalcTextSize ( player_name.c_str ( ) ) ;
                float text_x = head_screen.x - ( text_size.x / 2 ) ;
                float text_y = head_screen.y - 15 ;
                g::drawing.text ( player_name.c_str ( ) , ImVec2 ( text_x , text_y ) , vars::esp::name_color ) ;
                ImGui::PopFont ( ) ;
            }
        }

        auto local_character = utils::get_model_instance ( globals::local_player ) ;
        if ( local_character )
        {
            if ( vars::esp::esp_distance )
            {
                auto local_root_part = utils::find_first_child ( local_character , "HumanoidRootPart" ) ;
                auto player_root_part = utils::find_first_child ( character , "HumanoidRootPart" ) ;
                if ( local_root_part && player_root_part )
                {
                    auto local_primitive = driver.read< uintptr_t > ( local_root_part + 0x168 ) ;
                    auto player_primitive = driver.read< uintptr_t > ( player_root_part + 0x168 ) ;
                    if ( local_primitive && player_primitive )
                    {
                        Vector local_pos = driver.read< Vector > ( local_primitive + 0x140 ) ;
                        Vector player_pos = driver.read< Vector > ( player_primitive + 0x140 ) ;
                        float distance = ( local_pos - player_pos ).Length ( ) ;
                        if ( distance > 0.0f )
                        {
                            std::string distance_str = "[" + std::to_string ( static_cast< int > ( distance ) ) + "m]" ;
                            ImGui::PushFont ( pixelFont ) ;
                            ImVec2 dist_text_size = ImGui::CalcTextSize ( distance_str.c_str ( ) ) ;
                            float dist_text_x = ( box_top_left.x + box_bottom_right.x ) / 2 - ( dist_text_size.x / 2 ) ;
                            float dist_text_y = box_bottom_right.y + 2 ;
                            g::drawing.text ( distance_str.c_str ( ) , ImVec2 ( dist_text_x , dist_text_y ) , ImColor ( 255 , 255 , 255 ) ) ;
                            ImGui::PopFont ( ) ;
                        }
                    }
                }
            }
        }
    }

    if ( globals::teleport_target && vars::misc::teleport_arrow )
    {
        auto teleport_character = utils::get_model_instance ( globals::teleport_target ) ;
        if ( ! teleport_character )
        {
            return true ;
        }

        std::string player_name = utils::get_instance_name ( globals::teleport_target ) ;
        if ( player_name.empty ( ) )
        {
            return true ;
        }

        ImGui::PushFont ( verdanaFont ) ;
        ImVec2 text_size = ImGui::CalcTextSize ( player_name.c_str ( ) ) ;
        ImGui::PopFont ( ) ;

        Vector head_pos ;
        Vector2D head_screen ;
        bool head_valid = false ;

        if ( vars::esp::esp_mode == 1 )
        {
            auto head_result = get_part_position ( teleport_character , "Head" ) ;
            if ( ! head_result.second )
            {
                return true ;
            }
            head_pos = head_result.first ;
            head_valid = utils::world_to_screen ( head_pos , head_screen , view_matrix , 1920 , 1080 ) ;
        }
        else
        {
            auto head_result = get_part_position ( teleport_character , "Head" ) ;
            if ( ! head_result.second )
            {
                return true ;
            }
            head_pos = head_result.first + Vector ( 0 , 1.0f , 0 ) ;
            head_valid = utils::world_to_screen ( head_pos , head_screen , view_matrix , 1920 , 1080 ) ;
        }

        if ( ! head_valid )
        {
            return true ;
        }

        float name_margin = max ( 15.0f , text_size.y * 1.5f ) ;
        float name_text_y = head_screen.y - name_margin ;
        const float arrow_size = 11.0f ;
        ImVec2 arrow_tip ( head_screen.x , name_text_y + arrow_size ) ;
        ImVec2 arrow_base_left ( head_screen.x - arrow_size , name_text_y ) ;
        ImVec2 arrow_base_right ( head_screen.x + arrow_size , name_text_y ) ;
        const float outline_thickness = 2.0f ;
        ImDrawList * draw_list = ImGui::GetForegroundDrawList ( ) ;
        if ( draw_list )
        {
            draw_list->AddTriangleFilled (
                arrow_tip ,
                arrow_base_left ,
                arrow_base_right ,
                IM_COL32 ( 0 , 0 , 0 , 255 )
            ) ;
            ImVec2 inner_tip ( head_screen.x , name_text_y + arrow_size - outline_thickness ) ;
            ImVec2 inner_base_left ( head_screen.x - arrow_size + outline_thickness , name_text_y + outline_thickness ) ;
            ImVec2 inner_base_right ( head_screen.x + arrow_size - outline_thickness , name_text_y + outline_thickness ) ;
            draw_list->AddTriangleFilled (
                inner_tip ,
                inner_base_left ,
                inner_base_right ,
                vars::misc::teleport_arrow_color
            ) ;
        }
    }

    return true ;
}

bool CESP::draw_instances ( matrix view_matrix )
{
    auto now = std::chrono::steady_clock::now ( ) ;
    static auto last_cache_clear = now ;
    constexpr float CACHE_LIFETIME = 2.f ;
    static std::unordered_map< uintptr_t , std::unordered_set< uintptr_t > > drawable_cache ;
    if ( std::chrono::duration< float > ( now - last_cache_clear ).count ( ) > CACHE_LIFETIME )
    {
        drawable_cache.clear ( ) ;
        last_cache_clear = now ;
    }

    std::function< std::unordered_set< uintptr_t > ( uintptr_t , bool ) > get_drawable =
        [ & ] ( uintptr_t inst , bool root ) -> std::unordered_set< uintptr_t >
    {
        std::unordered_set< uintptr_t > result ;
        if ( inst == 0 )
        {
            return result ;
        }
        if ( drawable_cache.find ( inst ) != drawable_cache.end ( ) )
        {
            return drawable_cache[ inst ] ;
        }
        std::string type = utils::get_instance_classname ( inst ) ;
        if ( type.empty ( ) )
        {
            return result ;
        }
        if ( type == "Part" || type == "MeshPart" || type == "SpawnLocation" || type == "UnionOperation" )
        {
            result.insert ( inst ) ;
        }
        else if ( type == "Model" )
        {
            result.insert ( inst ) ;
            auto children = utils::children ( inst ) ;
            if ( ! children.empty ( ) )
            {
                for ( auto child : children )
                {
                    if ( child == 0 )
                    {
                        continue ;
                    }
                    std::string child_type = utils::get_instance_classname ( child ) ;
                    if ( child_type == "Model" )
                    {
                        auto child_drawables = get_drawable ( child , false ) ;
                        result.insert ( child_drawables.begin ( ) , child_drawables.end ( ) ) ;
                    }
                }
            }
        }
        else if ( type == "Folder" )
        {
            auto children = utils::children ( inst ) ;
            if ( ! children.empty ( ) )
            {
                for ( auto child : children )
                {
                    if ( child == 0 )
                    {
                        continue ;
                    }
                    std::string child_type = utils::get_instance_classname ( child ) ;
                    if ( child_type == "Folder" )
                    {
                        auto child_drawables = get_drawable ( child , false ) ;
                        result.insert ( child_drawables.begin ( ) , child_drawables.end ( ) ) ;
                    }
                    else if ( child_type == "Model" || child_type == "Part" ||
                              child_type == "MeshPart" || child_type == "SpawnLocation" || child_type == "UnionOperation" )
                    {
                        result.insert ( child ) ;
                    }
                }
            }
        }
        drawable_cache[ inst ] = result ;
        return result ;
    } ;

    auto get_part_position = [ ] ( uintptr_t model , const char * name ) -> std::pair< Vector , bool >
    {
        if ( model == 0 )
        {
            return { Vector ( ) , false } ;
        }
        auto part = utils::find_first_child ( model , name ) ;
        if ( ! part )
        {
            return { Vector ( ) , false } ;
        }
        auto primitive = driver.read< uintptr_t > ( part + 0x168 ) ;
        if ( ! primitive )
        {
            return { Vector ( ) , false } ;
        }
        Vector pos = driver.read< Vector > ( primitive + 0x140 ) ;
        return { pos , true } ;
    } ;

    std::unordered_set< uintptr_t > drawable_set ;
    for ( auto inst : flagged_instances )
    {
        if ( inst == 0 )
        {
            continue ;
        }
        auto drawables = get_drawable ( inst , true ) ;
        drawable_set.insert ( drawables.begin ( ) , drawables.end ( ) ) ;
    }

    for ( auto instance : drawable_set )
    {
        if ( instance == 0 )
        {
            continue ;
        }
        std::string class_name = utils::get_instance_classname ( instance ) ;
        std::string instance_name = utils::get_instance_name ( instance ) ;
        bool is_npc = false ;
        bool has_head = false ;
        if ( class_name == "Model" )
        {
            if ( utils::find_first_child_byclass ( instance , "Humanoid" ) )
            {
                is_npc = true ;
                if ( utils::find_first_child ( instance , "Head" ) )
                {
                    has_head = true ;
                }
            }
        }
        Vector position ;
        bool valid_position = false ;
        if ( class_name == "Part" || class_name == "MeshPart" || class_name == "SpawnLocation" || class_name == "UnionOperation" )
        {
            auto primitive = driver.read< uintptr_t > ( instance + 0x168 ) ;
            if ( primitive )
            {
                position = driver.read< Vector > ( primitive + 0x140 ) ;
                valid_position = true ;
            }
        }
        else if ( class_name == "Model" )
        {
            if ( ! is_npc )
            {
                auto humanoid_root = utils::find_first_child ( instance , "HumanoidRootPart" ) ;
                if ( humanoid_root )
                {
                    auto primitive = driver.read< uintptr_t > ( humanoid_root + 0x168 ) ;
                    if ( primitive )
                    {
                        position = driver.read< Vector > ( primitive + 0x140 ) ;
                        valid_position = true ;
                    }
                }
                else
                {
                    auto children = utils::children ( instance ) ;
                    if ( ! children.empty ( ) )
                    {
                        auto random_part = children.front ( ) ;
                        if ( random_part != 0 )
                        {
                            auto primitive = driver.read< uintptr_t > ( random_part + 0x168 ) ;
                            if ( primitive )
                            {
                                position = driver.read< Vector > ( primitive + 0x140 ) ;
                                valid_position = true ;
                            }
                        }
                    }
                }
            }
            else
            {
                auto humanoid_root = utils::find_first_child ( instance , "HumanoidRootPart" ) ;
                if ( humanoid_root )
                {
                    auto primitive = driver.read< uintptr_t > ( humanoid_root + 0x168 ) ;
                    if ( primitive )
                    {
                        position = driver.read< Vector > ( primitive + 0x140 ) ;
                        valid_position = true ;
                    }
                }
                else
                {
                    auto children = utils::children ( instance ) ;
                    if ( ! children.empty ( ) )
                    {
                        auto random_part = children.front ( ) ;
                        if ( random_part != 0 )
                        {
                            auto primitive = driver.read< uintptr_t > ( random_part + 0x168 ) ;
                            if ( primitive )
                            {
                                position = driver.read< Vector > ( primitive + 0x140 ) ;
                                valid_position = true ;
                            }
                        }
                    }
                }
            }
        }
        else if ( class_name == "Folder" )
        {
            continue ;
        }
        if ( ! valid_position )
        {
            continue ;
        }
        ImVec2 box_top_left , box_bottom_right ;
        bool use_large_box = false ;
        Vector2D head_screen , leg_screen , screen_pos ;
        if ( is_npc && has_head && ( vars::esp::esp_mode == 0 ) )
        {
            auto head_result = get_part_position ( instance , "Head" ) ;
            if ( head_result.second )
            {
                Vector head_pos = head_result.first + Vector ( 0 , 1.0f , 0 ) ;
                Vector leg_pos = head_result.first - Vector ( 0 , 5.0f , 0 ) ;
                bool head_valid = utils::world_to_screen ( head_pos , head_screen , view_matrix , 1920 , 1080 ) ;
                bool leg_valid = utils::world_to_screen ( leg_pos , leg_screen , view_matrix , 1920 , 1080 ) ;
                if ( head_valid && leg_valid )
                {
                    float box_height = leg_screen.y - head_screen.y ;
                    float box_width = box_height / 2.0f ;
                    box_width *= 1.2f ;
                    box_top_left = ImVec2 ( head_screen.x - box_width / 2 , head_screen.y ) ;
                    box_bottom_right = ImVec2 ( head_screen.x + box_width / 2 , leg_screen.y ) ;
                    use_large_box = true ;
                }
            }
        }
        if ( ! use_large_box )
        {
            if ( ! utils::world_to_screen ( position , screen_pos , view_matrix , 1920 , 1080 ) )
            {
                continue ;
            }
            float box_size = 10.0f ;
            box_top_left = ImVec2 ( screen_pos.x - box_size / 2 , screen_pos.y - box_size / 2 ) ;
            box_bottom_right = ImVec2 ( screen_pos.x + box_size / 2 , screen_pos.y + box_size / 2 ) ;
        }
        ImColor draw_color ;
        if ( is_npc )
        {
            draw_color = vars::esp::instances::esp_npc_color ;
        }
        else if ( class_name == "Model" )
        {
            draw_color = vars::esp::instances::esp_model_color ;
        }
        else
        {
            draw_color = vars::esp::instances::esp_part_color ;
        }
        if ( vars::esp::instances::esp_box )
        {
            if ( vars::esp::instances::esp_filled_box )
            {
                g::drawing.filled_box (
                    box_top_left ,
                    box_bottom_right ,
                    ImColor ( draw_color.Value.x , draw_color.Value.y , draw_color.Value.z , 0.5f )
                ) ;
            }
            g::drawing.outlined_box ( box_top_left , box_bottom_right , draw_color , ImColor ( 0 , 0 , 0 ) , 1.0f ) ;
        }
        float center_x = ( box_top_left.x + box_bottom_right.x ) / 2.0f ;
        if ( vars::esp::instances::esp_name )
        {
            ImGui::PushFont ( verdanaFont ) ;
            ImVec2 text_size = ImGui::CalcTextSize ( instance_name.c_str ( ) ) ;
            float text_x = center_x - ( text_size.x / 2 ) ;
            float text_y = box_top_left.y - text_size.y - 2 ;
            g::drawing.text ( instance_name.c_str ( ) , ImVec2 ( text_x , text_y ) , ImColor ( 255 , 255 , 255 ) ) ;
            ImGui::PopFont ( ) ;
        }
        if ( vars::esp::instances::esp_distance )
        {
            auto local_character = utils::get_model_instance ( globals::local_player ) ;
            if ( local_character )
            {
                auto local_rootpart = utils::find_first_child ( local_character , "HumanoidRootPart" ) ;
                if ( local_rootpart )
                {
                    auto local_primitive = driver.read< uintptr_t > ( local_rootpart + 0x168 ) ;
                    if ( local_primitive )
                    {
                        Vector local_pos = driver.read< Vector > ( local_primitive + 0x140 ) ;
                        float distance = ( local_pos - position ).Length ( ) ;
                        std::string distance_str = "[" + std::to_string ( static_cast< int > ( distance ) ) + "m]" ;
                        ImGui::PushFont ( pixelFont ) ;
                        ImVec2 dist_text_size = ImGui::CalcTextSize ( distance_str.c_str ( ) ) ;
                        float dist_text_x = center_x - ( dist_text_size.x / 2 ) ;
                        float dist_text_y = box_bottom_right.y + 2 ;
                        g::drawing.text ( distance_str.c_str ( ) , ImVec2 ( dist_text_x , dist_text_y ) , ImColor ( 255 , 255 , 255 ) ) ;
                        ImGui::PopFont ( ) ;
                    }
                }
            }
        }
        if ( is_npc )
        {
            auto humanoid = utils::find_first_child_byclass ( instance , "Humanoid" ) ;
            if ( humanoid )
            {
                float health = driver.read< float > ( humanoid + roblox::offsets::Health ) ;
                health = std::clamp ( health , 0.0f , 100.0f ) ;
                ImColor health_color ;
                if ( health >= 75.0f )
                {
                    health_color = ImColor ( 0 , 255 , 0 ) ;
                }
                else if ( health >= 30.0f )
                {
                    health_color = ImColor ( 255 , 255 , 0 ) ;
                }
                else
                {
                    health_color = ImColor ( 255 , 0 , 0 ) ;
                }
                float box_height = box_bottom_right.y - box_top_left.y ;
                float health_bar_width = 2.2f ;
                float health_bar_height = box_height * ( health / 100.0f ) ;
                ImVec2 health_bar_bottom_left ( box_top_left.x - health_bar_width - 3.5f , box_top_left.y + box_height ) ;
                ImVec2 health_bar_top_right ( health_bar_bottom_left.x + health_bar_width , box_top_left.y + box_height - health_bar_height ) ;
                if ( vars::esp::instances::esp_health_bar )
                {
                    g::drawing.outlined_box (
                        ImVec2 ( health_bar_bottom_left.x , box_top_left.y ) ,
                        ImVec2 ( health_bar_top_right.x , box_top_left.y + box_height ) ,
                        ImColor ( 0 , 0 , 0 , 255 ) ,
                        ImColor ( 0 , 0 , 0 , 255 ) ,
                        1.0f
                    ) ;
                    g::drawing.filled_box (
                        health_bar_top_right ,
                        ImVec2 ( health_bar_bottom_left.x , box_top_left.y + box_height ) ,
                        health_color
                    ) ;
                }
                if ( vars::esp::instances::esp_health_number && static_cast< int > ( health ) != 100 )
                {
                    std::string health_text = std::to_string ( static_cast< int > ( health ) ) ;
                    ImVec2 health_text_size = ImGui::CalcTextSize ( health_text.c_str ( ) ) ;
                    ImVec2 health_text_pos (
                        health_bar_bottom_left.x + ( health_bar_width - health_text_size.x ) * 0.5f ,
                        health_bar_top_right.y - ( health_text_size.y * 0.5f )
                    ) ;
                    ImGui::PushFont ( pixelFont ) ;
                    g::drawing.text ( health_text.c_str ( ) , health_text_pos , ImColor ( 255 , 255 , 255 ) ) ;
                    ImGui::PopFont ( ) ;
                }
            }
        }
    }

    return true ;
}

#include "image_handler.h"

void CImageHandler::create_images() {
    if (globals::images_init) return;

    D3DX11_IMAGE_LOAD_INFO info{};
    ID3DX11ThreadPump* pump{ nullptr };

    auto load_image = [](const void* data, size_t size, ID3D11ShaderResourceView** image) {
        if (FAILED(D3DX11CreateShaderResourceViewFromMemory(dx_device, data, size, nullptr, nullptr, image, nullptr))) {
            utils::console_print_color(__FILE__, "epic fail");
        }
        };

    load_image(aim_image_data, sizeof(aim_image_data), &aim_image);
    load_image(visuals_image_data, sizeof(visuals_image_data), &visuals_image);
    load_image(misc_image_data, sizeof(misc_image_data), &misc_image);
    load_image(players_menu_image_data, sizeof(players_menu_image_data), &players_menu_image);
    load_image(config_image_data, sizeof(config_image_data), &config_image);
    load_image(lua_image_data, sizeof(lua_image_data), &lua_image);
    load_image(workspace_image_data, sizeof(workspace_image_data), &workspace_image);
    load_image(part_image_data, sizeof(part_image_data), &part_image);
    load_image(model_image_data, sizeof(model_image_data), &model_image);
    load_image(folder_image_data, sizeof(folder_image_data), &folder_image);
    load_image(camera_image_data, sizeof(camera_image_data), &camera_image);
    load_image(script_image_data, sizeof(script_image_data), &script_image);
    load_image(local_script_image_data, sizeof(local_script_image_data), &local_script_image);
    load_image(players_image_data, sizeof(players_image_data), &players_image);
    load_image(humanoid_image_data, sizeof(humanoid_image_data), &humanoid_image);
    load_image(accessory_image_data, sizeof(accessory_image_data), &accessory_image);
    load_image(sound_image_data, sizeof(sound_image_data), &sound_image);
    load_image(replicated_storage_image_data, sizeof(replicated_storage_image_data), &replicated_storage_image);
    load_image(hat_image_data, sizeof(hat_image_data), &hat_image);
    load_image(player_image_data, sizeof(player_image_data), &player_image);
    load_image(module_script_image_data, sizeof(module_script_image_data), &module_script_image);
    load_image(run_service_image_data, sizeof(run_service_image_data), &run_service_image);
    load_image(spawn_location_image_data, sizeof(spawn_location_image_data), &spawn_location_image);
    load_image(stats_image_data, sizeof(stats_image_data), &stats_image);
    load_image(starter_gui_image_data, sizeof(starter_gui_image_data), &starter_gui_image);
    load_image(replicated_first_image_data, sizeof(replicated_first_image_data), &replicated_first_image);
    load_image(chat_image_data, sizeof(chat_image_data), &chat_image);
    load_image(starter_pack_image_data, sizeof(starter_pack_image_data), &starter_pack_image);
    load_image(gui_service_image_data, sizeof(gui_service_image_data), &gui_service_image);
    load_image(core_gui_image_data, sizeof(core_gui_image_data), &core_gui_image);

    globals::images_init = true;
}

void CImageHandler::release_images() {
    auto release_image = [](ID3D11ShaderResourceView*& image) {
        if (image) {
            image->Release();
            image = nullptr;
        }
        };

    release_image(aim_image);
    release_image(visuals_image);
    release_image(misc_image);
    release_image(workspace_image);
    release_image(part_image);
    release_image(model_image);
    release_image(folder_image);
    release_image(camera_image);
    release_image(script_image);
    release_image(local_script_image);
    release_image(players_image);
    release_image(humanoid_image);
    release_image(accessory_image);
    release_image(sound_image);
    release_image(replicated_storage_image);
    release_image(hat_image);
    release_image(player_image);
    release_image(module_script_image);
    release_image(run_service_image);
    release_image(spawn_location_image);
    release_image(stats_image);
    release_image(starter_gui_image);
    release_image(replicated_first_image);
    release_image(chat_image);
    release_image(starter_pack_image);
    release_image(gui_service_image);
    release_image(core_gui_image);

    globals::images_init = false;
}
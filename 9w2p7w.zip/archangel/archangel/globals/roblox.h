#include <cstdint>

namespace roblox
{
    namespace offsets
    {
        constexpr uintptr_t Size = 0x8;
        constexpr uintptr_t Name = 0x70;
        constexpr uintptr_t Children = 0x78;
        constexpr uintptr_t ClassDescriptor = 0x18;
        constexpr uintptr_t Parent = 0x50;

        // Main
        constexpr uintptr_t DataModelPointer = 0x5BF4B58;
        constexpr uintptr_t VisualEnginePointer = 0x5A27D80;
        constexpr uintptr_t FakeToRealDataModel = 0x1B8;

        // Misc
        constexpr uintptr_t PlaceID = 0x170;
        constexpr uintptr_t LocalPlayer = 0x120;
        constexpr uintptr_t Health = 0x198;
        constexpr uintptr_t Team = 0x200;
    }
};
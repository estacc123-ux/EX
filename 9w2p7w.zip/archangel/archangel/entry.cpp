#include "entry.h"
#include "features/aimbot.h"

void rescan_thread()
{
    std::uint64_t last_place_id = driver.read<std::uint64_t>(globals::datamodel + 0x178);

    while (true)
    {
        std::this_thread::sleep_for(std::chrono::seconds(1));

        auto image_base = driver.find_image();
        auto game = driver.read<std::uint64_t>(image_base + 0x612FDA8);
        if (!game)
            continue;

        auto new_datamodel = driver.read<std::uint64_t>(game + 0x1B8);
        if (!new_datamodel)
            continue;

        std::uint64_t current_place_id = driver.read<std::uint64_t>(new_datamodel + 0x178);

        if (current_place_id == 0 || current_place_id != last_place_id)
        {
            auto new_visual_engine = driver.read<std::uint64_t>(image_base + 0x5F407A0);

            uintptr_t new_local_player = 0;
            for (int i = 0; i < 20; ++i)
            {
                new_local_player = driver.read<uintptr_t>(
                    utils::find_first_child_byclass(new_datamodel, "Players") + roblox::offsets::LocalPlayer
                );
                std::this_thread::sleep_for(std::chrono::milliseconds(65));
            }

            globals::datamodel = new_datamodel;
            globals::visual_engine = new_visual_engine;
            globals::local_player = new_local_player;

            utils::console_print_rescan(__FILE__,
                "Updated");

            utils::console_print_rescan(__FILE__, "Datamodel -> %0x%lx", new_datamodel);

            utils::console_print_rescan(__FILE__, "Place-ID -> %llu", current_place_id);

            if (current_place_id != 0)
                last_place_id = current_place_id;
        }
    }
}

int main( )
{
	utils::initialize_console( );

    auto process = driver.find_process( "RobloxPlayerBeta.exe" );

    if ( !driver.find_driver( ) || !process )
        return_false( );

    auto game = driver.read< std::uint64_t >( driver.find_image( ) + 0x612FDA8);

    auto visual_engine_pointer = driver.read< std::uint64_t >( driver.find_image() + 0x5F407A0);

    auto data_model = driver.read< std::uint64_t >( game + 0x1B8 );

    auto place_id = driver.read< std::uint64_t >( data_model + 0x178);

    auto local_player = driver.read<uintptr_t>(utils::find_first_child_byclass(data_model, "Players") + roblox::offsets::LocalPlayer);
    
    utils::console_print_color( __FILE__, "Datamodel -> %0x%lx", data_model );

    utils::console_print_color( __FILE__, "Place-ID -> %llu", place_id );

    globals::datamodel = data_model;

    globals::visual_engine = visual_engine_pointer;

    globals::local_player = local_player;

    //std::thread __rescan_thread(rescan_thread);

	overlay::render( );
}
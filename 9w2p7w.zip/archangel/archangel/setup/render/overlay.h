#pragma once
#define d_toggle_bind 0x2D /* VK_INSERT */

namespace overlay
{
    inline void setup_style()
    {
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowPadding = ImVec2(6, 6);
        style.WindowRounding = 4.0f;
        style.ChildRounding = 4.0f;
        style.FramePadding = ImVec2(4, 3);
        style.FrameRounding = 3.0f;
        style.ItemSpacing = ImVec2(6, 6);
        style.ItemInnerSpacing = ImVec2(3, 3);
        style.ScrollbarSize = 2.0f;
        style.GrabMinSize = 6.0f;
        style.GrabRounding = 3.0f;
        style.PopupRounding = 3.0f;
        style.Alpha = 1.0f;
        style.IndentSpacing = 20.0f;

        // Darker accent colors
        ImVec4 accent_color = ImVec4(0.137f, 0.137f, 0.137f, 1.00f);         // RGB(35, 35, 35)
        ImVec4 accent_color_hovered = ImVec4(0.176f, 0.176f, 0.176f, 1.00f); // RGB(45, 45, 45)
        ImVec4 accent_color_active = ImVec4(0.216f, 0.216f, 0.216f, 1.00f);  // RGB(55, 55, 55)

        ImVec4 highlight = ImVec4(0.157f, 0.157f, 0.157f, 1.00f);            // RGB(40, 40, 40)

        ImVec4* colors = style.Colors;
        colors[ImGuiCol_WindowBg] = ImVec4(0.078f, 0.078f, 0.078f, 1.00f);   // RGB(20, 20, 20)
        colors[ImGuiCol_ChildBg] = ImVec4(0.098f, 0.098f, 0.098f, 1.00f);    // RGB(25, 25, 25)
        colors[ImGuiCol_Border] = ImVec4(0.137f, 0.137f, 0.137f, 1.00f);     // RGB(35, 35, 35)
        colors[ImGuiCol_BorderShadow] = ImVec4(0.000f, 0.000f, 0.000f, 0.00f);

        colors[ImGuiCol_FrameBg] = ImVec4(0.098f, 0.098f, 0.098f, 1.00f);        // RGB(25, 25, 25)
        colors[ImGuiCol_FrameBgHovered] = ImVec4(0.137f, 0.137f, 0.137f, 1.00f); // RGB(35, 35, 35)
        colors[ImGuiCol_FrameBgActive] = ImVec4(0.157f, 0.157f, 0.157f, 1.00f);  // RGB(40, 40, 40)

        // Button colors
        colors[ImGuiCol_Button] = accent_color;
        colors[ImGuiCol_ButtonHovered] = accent_color_hovered;
        colors[ImGuiCol_ButtonActive] = accent_color_active;

        // Header colors
        colors[ImGuiCol_Header] = accent_color;
        colors[ImGuiCol_HeaderHovered] = accent_color_hovered;
        colors[ImGuiCol_HeaderActive] = accent_color_active;

        // Text colors
        colors[ImGuiCol_Text] = ImVec4(0.855f, 0.855f, 0.855f, 1.00f);           // Light gray text
        colors[ImGuiCol_TextDisabled] = ImVec4(0.500f, 0.500f, 0.500f, 1.00f);   // Darker gray for disabled

        // Interactive elements
        colors[ImGuiCol_CheckMark] = ImVec4(0.647f, 0.647f, 0.647f, 1.00f);      // RGB(165, 165, 165)
        colors[ImGuiCol_SliderGrab] = ImVec4(0.647f, 0.647f, 0.647f, 1.00f);     // RGB(165, 165, 165)
        colors[ImGuiCol_SliderGrabActive] = ImVec4(0.725f, 0.725f, 0.725f, 1.00f);// RGB(185, 185, 185)

        // Scrollbar
        colors[ImGuiCol_ScrollbarBg] = ImVec4(0.078f, 0.078f, 0.078f, 1.00f);    // RGB(20, 20, 20)
        colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.137f, 0.137f, 0.137f, 1.00f);  // RGB(35, 35, 35)
        colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.157f, 0.157f, 0.157f, 1.00f);
        colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.176f, 0.176f, 0.176f, 1.00f);

        // Popups and Tooltips
        colors[ImGuiCol_PopupBg] = ImVec4(0.078f, 0.078f, 0.078f, 1.00f);        // RGB(20, 20, 20)
        colors[ImGuiCol_TitleBg] = ImVec4(0.078f, 0.078f, 0.078f, 1.00f);
        colors[ImGuiCol_TitleBgActive] = accent_color;
        colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.078f, 0.078f, 0.078f, 0.75f);

        // Tables
        colors[ImGuiCol_TableHeaderBg] = accent_color;
        colors[ImGuiCol_TableBorderStrong] = ImVec4(0.157f, 0.157f, 0.157f, 1.00f);
        colors[ImGuiCol_TableBorderLight] = ImVec4(0.137f, 0.137f, 0.137f, 1.00f);
        colors[ImGuiCol_TableRowBg] = ImVec4(0.078f, 0.078f, 0.078f, 1.00f);
        colors[ImGuiCol_TableRowBgAlt] = ImVec4(0.098f, 0.098f, 0.098f, 1.00f);

        // Tabs
        colors[ImGuiCol_Tab] = accent_color;
        colors[ImGuiCol_TabHovered] = accent_color_hovered;
        colors[ImGuiCol_TabActive] = accent_color_active;
        colors[ImGuiCol_TabUnfocused] = ImVec4(0.098f, 0.098f, 0.098f, 1.00f);
        colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.137f, 0.137f, 0.137f, 1.00f);
    }


	void render();

	inline bool enabled = true;
}
#include "../../entry.h"

#include < dwmapi.h >
#include < d3dx11.h >
#include "../../features/menu.h"
//#include "../imgui/imgui_freetype.h"
#include "../../features/aimbot.h"
#include "../../features/esp.h"
#include "../../features/image_handler.h"
#include < iostream >
#include "../../features/misc.h"

static ID3D11Device * g_pd3d_device = nullptr;
static ID3D11DeviceContext * g_pd3d_device_context = nullptr;
static IDXGISwapChain * g_p_swap_chain = nullptr;
static UINT g_resize_width = 0, g_resize_height = 0;
static ID3D11RenderTargetView * g_main_render_target_view = nullptr;

bool create_device_d3d( HWND h_wnd );
void cleanup_device_d3d();
void create_render_target();
void cleanup_render_target();
LRESULT WINAPI wnd_proc( HWND h_wnd, UINT msg, WPARAM w_param, LPARAM l_param );

void overlay::render()
{
    WNDCLASSEXW wc = { sizeof ( wc ) , CS_CLASSDC , wnd_proc , 0L , 0L , GetModuleHandle ( nullptr ) , nullptr , nullptr , nullptr , nullptr , L"Task Manager" , nullptr };
    ::RegisterClassExW ( & wc );
    HWND hwnd = ::CreateWindowExW ( WS_EX_TOPMOST | WS_EX_TOOLWINDOW, wc.lpszClassName, L"Task Manager", WS_POPUP,
        0, 0, GetSystemMetrics ( SM_CXSCREEN ), GetSystemMetrics ( SM_CYSCREEN ), nullptr, nullptr, wc.hInstance, nullptr );

    SetLayeredWindowAttributes ( hwnd, RGB( 0, 0, 0 ), 255, LWA_ALPHA );
    MARGINS margin = { -1 };
    DwmExtendFrameIntoClientArea ( hwnd, & margin );

    if ( ! create_device_d3d ( hwnd ) )
    {
        cleanup_device_d3d();
        ::UnregisterClassW ( wc.lpszClassName, wc.hInstance );
        return;
    }

    ::ShowWindow ( hwnd, SW_SHOWDEFAULT );
    ::UpdateWindow ( hwnd );

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO & io = ImGui::GetIO(); ( void ) io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;
    ImGui::StyleColorsDark();

    ImGui_ImplWin32_Init( hwnd );
    ImGui_ImplDX11_Init( g_pd3d_device, g_pd3d_device_context );

    dx_device = g_pd3d_device;
    image_handler.create_images();

    setup_style();

    ImVec4 clear_color = ImVec4 ( 0.f, 0.f, 0.f, 0.f );

    /*ImFontConfig menu_cfg;
    menu_cfg.OversampleH = 3;
    menu_cfg.OversampleV = 3;
    menu_cfg.PixelSnapH = true;
    io.Fonts->AddFontFromFileTTF( "C:\\Windows\\Fonts\\arial.ttf", 15.f, & menu_cfg, io.Fonts->GetGlyphRangesCyrillic( ) );

    ImFontConfig menu_small_cfg;
    menu_small_cfg.OversampleH = 3;
    menu_small_cfg.OversampleV = 3;
    menu_small_cfg.PixelSnapH = true;
    menuSmallFont = io.Fonts->AddFontFromFileTTF( "C:\\Windows\\Fonts\\arial.ttf", 12.f, & menu_small_cfg, io.Fonts->GetGlyphRangesCyrillic( ) );

    ImFontConfig verdana_cfg;
    verdana_cfg.OversampleH = 3;
    verdana_cfg.OversampleV = 3;
    verdana_cfg.PixelSnapH = true;
    verdanaFont = io.Fonts->AddFontFromFileTTF( "C:\\Windows\\Fonts\\verdana.ttf", 11.f, & verdana_cfg, io.Fonts->GetGlyphRangesCyrillic( ) );

    ImFontConfig pixel_cfg;
    pixel_cfg.OversampleH = 3;
    pixel_cfg.OversampleV = 3;
    pixel_cfg.PixelSnapH = true;
    pixelFont = io.Fonts->AddFontFromFileTTF( "C:\\Windows\\Fonts\\smallest_pixel-7.ttf", 11.0f, & pixel_cfg, io.Fonts->GetGlyphRangesCyrillic( ) );*/

    bool done = false;
    while ( ! done )
    {
        if ( GetAsyncKeyState ( d_toggle_bind ) & 1 )
        {
            overlay::enabled = ! overlay::enabled;
        }

        MSG msg;
        while ( ::PeekMessage ( & msg, nullptr, 0U, 0U, PM_REMOVE ) )
        {
            ::TranslateMessage ( & msg );
            ::DispatchMessage ( & msg );
            if ( msg.message == WM_QUIT )
            {
                done = true;
                break;
            }
        }
        if ( done )
        {
            break;
        }

        if ( g_resize_width != 0 && g_resize_height != 0 && g_p_swap_chain )
        {
            cleanup_render_target();
            HRESULT hr = g_p_swap_chain->ResizeBuffers( 0, g_resize_width, g_resize_height, DXGI_FORMAT_UNKNOWN, 0 );
            if ( FAILED ( hr ) )
            {
                MessageBox(NULL, "idi nahuj", "idi nahuj p diddy", 0);
            }
            g_resize_width = g_resize_height = 0;
            create_render_target();
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        d::menu.draw_keybinds( );

        if ( overlay::enabled )
        {
            d::menu.draw_menu( );
            LONG ex_style = GetWindowLong( hwnd, GWL_EXSTYLE );
            if ( ex_style & WS_EX_TRANSPARENT )
            {
                ex_style &= ~WS_EX_TRANSPARENT;
                SetWindowLong( hwnd, GWL_EXSTYLE, ex_style );
                SetWindowPos( hwnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED );
            }
        }
        else
        {
            HWND roblox_window = FindWindowA( NULL, "Roblox" );
            if ( GetForegroundWindow( ) == roblox_window )
            {
                if ( globals::local_player && globals::datamodel )
                {
                    if ( globals::visual_engine )
                    {
                        view_matrix = driver.read< matrix >( globals::visual_engine + 0x4D0 );
                    }

                    if ( vars::aimbot::circle_target::enabled )
                    {
                        fs::aimbot.circle_target( );
                    }

                    if ( vars::aimbot::aimbot_enabled )
                    {
                        fs::aimbot.aim_at_closest_player( view_matrix );
                    }

                    fs::esp.draw_players( view_matrix );
                    fs::misc.teleport_to_nearest( view_matrix );
                    fs::esp.draw_instances( view_matrix );
                    fs::misc.noclip( );
                }
            }
            if ( vars::aimbot::fov_circle )
            {
                POINT current_cursor;
                if (GetCursorPos( &current_cursor ) )
                {
                    ImVec2 center( static_cast < float > ( current_cursor.x ), static_cast < float > ( current_cursor.y ) );
                    g::drawing.circle( center, vars::aimbot::fov_value, vars::visuals::fov_circle_color, 1.5f );
                }
            }

            LONG ex_style = GetWindowLong( hwnd, GWL_EXSTYLE );
            if ( ( ex_style & WS_EX_TRANSPARENT ) == 0 )
            {
                ex_style |= WS_EX_TRANSPARENT | WS_EX_LAYERED;
                SetWindowLong( hwnd, GWL_EXSTYLE, ex_style );
                SetWindowPos( hwnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED );
            }
        }


        ImGui::Render();
        const float clear_color_with_alpha[ 4 ] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
        if ( g_pd3d_device_context && g_main_render_target_view )
        {
            g_pd3d_device_context->OMSetRenderTargets( 1, & g_main_render_target_view, nullptr );
            g_pd3d_device_context->ClearRenderTargetView( g_main_render_target_view, clear_color_with_alpha );
            ImGui_ImplDX11_RenderDrawData( ImGui::GetDrawData() );
            if ( g_p_swap_chain )
            {
                g_p_swap_chain->Present( 0, 0 );
            }
        }
    }

    ImGui_ImplDX11_Shutdown( );
    ImGui_ImplWin32_Shutdown( );
    ImGui::DestroyContext( );

    cleanup_device_d3d( );
    ::DestroyWindow( hwnd );
    ::UnregisterClassW ( wc.lpszClassName, wc.hInstance );
}

bool create_device_d3d( HWND h_wnd )
{
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory( & sd, sizeof ( sd ) );
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 360;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = h_wnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT create_device_flags = 0;
    D3D_FEATURE_LEVEL feature_level;
    const D3D_FEATURE_LEVEL feature_level_array[ 2 ] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    HRESULT res = D3D11CreateDeviceAndSwapChain( nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, create_device_flags, feature_level_array, 2, D3D11_SDK_VERSION, & sd, & g_p_swap_chain, & g_pd3d_device, & feature_level, & g_pd3d_device_context );
    if ( res == DXGI_ERROR_UNSUPPORTED )
    {
        res = D3D11CreateDeviceAndSwapChain( nullptr, D3D_DRIVER_TYPE_WARP, nullptr, create_device_flags, feature_level_array, 2, D3D11_SDK_VERSION, & sd, & g_p_swap_chain, & g_pd3d_device, & feature_level, & g_pd3d_device_context );
    }
    if ( res != S_OK )
    {
        return false;
    }

    create_render_target();
    return true;
}

void cleanup_device_d3d()
{
    cleanup_render_target();
    if ( g_p_swap_chain )
    {
        g_p_swap_chain->Release();
        g_p_swap_chain = nullptr;
    }
    if ( g_pd3d_device_context )
    {
        g_pd3d_device_context->Release();
        g_pd3d_device_context = nullptr;
    }
    if ( g_pd3d_device )
    {
        g_pd3d_device->Release();
        g_pd3d_device = nullptr;
    }
}

void create_render_target()
{
    ID3D11Texture2D * p_back_buffer = nullptr;
    if ( g_p_swap_chain && SUCCEEDED( g_p_swap_chain->GetBuffer( 0, IID_PPV_ARGS( & p_back_buffer ) ) ) )
    {
        g_pd3d_device->CreateRenderTargetView( p_back_buffer, nullptr, & g_main_render_target_view );
        p_back_buffer->Release();
    }
}

void cleanup_render_target()
{
    if ( g_main_render_target_view )
    {
        g_main_render_target_view->Release();
        g_main_render_target_view = nullptr;
    }
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler( HWND h_wnd, UINT msg, WPARAM w_param, LPARAM l_param );

LRESULT WINAPI wnd_proc( HWND h_wnd, UINT msg, WPARAM w_param, LPARAM l_param )
{
    if ( ImGui_ImplWin32_WndProcHandler( h_wnd, msg, w_param, l_param ) )
    {
        return true;
    }

    switch ( msg )
    {
    case WM_SIZE:
    {
        if ( w_param == SIZE_MINIMIZED )
        {
            return 0;
        }
        g_resize_width = ( UINT ) LOWORD( l_param );
        g_resize_height = ( UINT ) HIWORD( l_param );
        return 0;
    }
    case WM_SYSCOMMAND:
    {
        if ( ( w_param & 0xfff0 ) == SC_KEYMENU )
        {
            return 0;
        }
        break;
    }
    case WM_DESTROY:
    {
        ::PostQuitMessage( 0 );
        return 0;
    }
    }
    return ::DefWindowProcW( h_wnd, msg, w_param, l_param );
}

namespace aim {
	void watchdog();
}
am proekts imito vakvekneb rom aghar vmushaob amaze.... uketes versiaze gadavedi romelic shegidzliat [ak naxot](https://www.youtube.com/watch?v=e597b9ZtmCo) :) raghaceebi gafuchebulia da checkebia chasasworebeli magram Datamodelis amogheba da ase shemdeg xerxdeba..... is versia aramgonia axlo momavalshi gamovushva mara es daichit :):):):):)):)💯

![image](https://github.com/user-attachments/assets/a29223e1-aaef-4b62-a040-7368538a4446)

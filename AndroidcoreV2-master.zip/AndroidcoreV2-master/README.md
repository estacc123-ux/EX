# AndroidcoreV2

Android ROBLOX Cheat for 64bits, only has basic custom environment since adding **alot** of functions will be a bad idea. Great learning resouce
The base is actually kinda mid, it's up to you if you will use this source. This is great to those who wants to start ROBLOX Android Modding but dont know where to start!
Happy Exploiting!

Updated for ROBLOX 2.654.474

THIS IS MADE IN UNDER 1 HOUR.
going to actively work on it lol

# WHAT TO DO :
- Add Http Functions
- Better ScriptContext handling
- Improve stability
- Add yielding function
- Add capabilities / identities
- Add custom functions
- Add reflection

# LIBRARIES NEEDED :
- libc++_shared.so

# CREDITS :
MBv2 for registry / closures, i dont want to use my closures since its open source:)

**TO LOAD ANDROIDCORE, LOCATE ROBLOX MAIN ACTIVITY AND FIND ONCREATE AND ADD THIS BELOW**
```
const-string v0, "Androidcore"
invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
```
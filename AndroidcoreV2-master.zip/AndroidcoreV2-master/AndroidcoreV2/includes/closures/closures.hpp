#pragma once

#include <lobject.h>
#include <lua.h>
#include <unordered_map>

namespace androidcore::closures {
	extern std::unordered_map<Closure*, lua_CFunction> cclosure;
	extern std::unordered_map<Closure*, Closure*> new_cclosure;

	auto pcallhandler(lua_State* ls) -> int;
	auto pushcclosure(lua_State* ls, lua_CFunction fn, const char* debugname, int nups) -> void;
}
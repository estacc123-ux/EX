#include "closures.hpp"

#include <lstate.h>
#include <lapi.h>

std::unordered_map<Closure*, lua_CFunction> androidcore::closures::cclosure = { };
std::unordered_map<Closure*, Closure*> androidcore::closures::new_cclosure = { };

auto androidcore::closures::pcallhandler(lua_State* ls) -> int
{
	auto closures = cclosure.find(curr_func(ls));

	if (closures != cclosure.end())
	{
		return closures->second(ls);
	}
	return 0;
}

auto androidcore::closures::pushcclosure(lua_State* ls, lua_CFunction fn, const char* libname, int nups) -> void
{
	lua_pushcclosurek(ls, pcallhandler, libname, nups, 0);
	cclosure[clvalue(luaA_toobject(ls, -1))] = fn;
}
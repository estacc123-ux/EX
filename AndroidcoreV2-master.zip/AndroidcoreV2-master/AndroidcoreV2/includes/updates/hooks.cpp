#include "hooks.hpp"

#include "../../androidcore/environment.hpp"
#include "../memory/memory.hpp"
#include "../updates/updates.hpp"
#include <And64InlineHook.hpp>

void* scriptstart_original{ nullptr };
int64_t scriptstart_hook(int64_t thiz, int64_t provider)
{
	auto original = *reinterpret_cast<decltype(&scriptstart_hook)>(scriptstart_original);
	auto retrieved = original(thiz, provider);

	androidcore::environment::GetSingleton().start(thiz);

	return retrieved;
}

void* ongameload_original{ nullptr };
int64_t ongameload_hook(void* a1, void* a2, int64_t thiz)
{
	auto original = *reinterpret_cast<decltype(&ongameload_hook)>(ongameload_original);
	auto retrieved = original(a1, a2, thiz);

	if (thiz)
	{
		androidcore::environment::GetSingleton().initiate(thiz);
	}

	return retrieved;
}

void* capabilitycheck_original{ nullptr };
int64_t capabilitycheck_hook(int64_t capability, const char* operation, const char* obj)
{
	// Opens alot of vulnerabilities, BUT WHO CARES WE ARE OPEN SOURCE WOOO!!
}

auto androidcore::hooks::attach() -> void
{
	LOGD("Attempting to call androidcore::hooks::attach");
	A64HookFunction(reinterpret_cast<void*>(memory::getAbsoluteAddress("libroblox.so", 0x29790A4)), reinterpret_cast<void*>(&scriptstart_hook), reinterpret_cast<void**>(&scriptstart_original));
	A64HookFunction(reinterpret_cast<void*>(memory::getAbsoluteAddress("libroblox.so", 0x23AFD60)), reinterpret_cast<void*>(&ongameload_hook), reinterpret_cast<void**>(&ongameload_original));
	A64HookFunction(reinterpret_cast<void*>(memory::getAbsoluteAddress("libroblox.so", 0x5D44284)), reinterpret_cast<void*>(&capabilitycheck_hook), reinterpret_cast<void**>(&capabilitycheck_original));
}
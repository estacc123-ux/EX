#pragma once

#include <cstdint>
#include <lstate.h>

// ROBLOX 2.654.474 : NO NEED TO EXPLAIN WHAT THIS IS. //

namespace androidcore {
	namespace updates {
		constexpr std::uint64_t rbx_globalstate = 0x29313C4;

		constexpr std::uint64_t rbx_stdout = 0x3A08BD8;
		constexpr std::uint64_t rbx_luanewthread = 0x513EC34;
		constexpr std::uint64_t rbx_luauload = 0x513EC34;
	}

	namespace structs {
		enum stdout_types : uint8_t
		{
			print,
			info,
			warn,
			error
		};
	}

	namespace functions {
		using rbx_globalstate = lua_State * (*)(std::int64_t sc, int* identity_info, int64_t* thread_script);
		using rbx_stdout = std::int64_t(*)(structs::stdout_types type, const char* fmt, ...);
		using rbx_luanewthread = lua_State * (*)(lua_State* rL);
		using rbx_luauload = int(*)(lua_State* rL, const char* chunkname, const char* data, size_t sz, int env);
	}

	inline functions::rbx_globalstate rbx_globalstate = nullptr;
	inline functions::rbx_stdout rbx_stdout = nullptr;
	inline functions::rbx_luanewthread rbx_luanewthread = nullptr;
	inline functions::rbx_luauload rbx_luauload = nullptr;

	auto grabGlobalState(int64_t sc) -> lua_State*;
	auto attach() -> void;
}
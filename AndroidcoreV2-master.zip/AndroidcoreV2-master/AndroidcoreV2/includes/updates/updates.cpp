#include "updates.hpp"
#include "../memory/memory.hpp"

auto androidcore::attach() -> void
{
	LOGD("Attempting to call androidcore::attach");
	rbx_globalstate = reinterpret_cast<decltype(rbx_globalstate)>(memory::getAbsoluteAddress("libroblox.so", updates::rbx_globalstate));
	rbx_stdout = reinterpret_cast<decltype(rbx_stdout)>(memory::getAbsoluteAddress("libroblox.so", updates::rbx_stdout));
	rbx_luanewthread = reinterpret_cast<decltype(rbx_luanewthread)>(memory::getAbsoluteAddress("libroblox.so", updates::rbx_luanewthread));
	rbx_luauload = reinterpret_cast<decltype(rbx_luauload)>(memory::getAbsoluteAddress("libroblox.so", updates::rbx_luauload));
}

auto androidcore::grabGlobalState(int64_t sc) -> lua_State*
{
	LOGD("Attempting to call androidcore::getGlobalState");
	int identity = 0;
	int64_t scr = 0;

	auto ls = rbx_globalstate(sc - 1448, &identity, &scr);
	return ls;
}
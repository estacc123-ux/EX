#pragma once

namespace androidcore::hooks {
	auto attach() -> void;
}
#include "memory.hpp"

static uint64_t libBase;

auto memory::findLibrary(const char* library) -> std::uint64_t
{
	char filename[0xFF] = { 0 },
		buffer[1024] = { 0 };
	FILE* fp = NULL;
	std::uint64_t address = 0;

	sprintf(filename, "/proc/self/maps");

	fp = fopen(filename, "rt");
	if (fp == NULL) {
		perror("fopen");
		goto done;
	}

	while (fgets(buffer, sizeof(buffer), fp)) {
		if (strstr(buffer, library)) {
			address = static_cast<std::uint64_t>(strtoul(buffer, NULL, 16));
			goto done;
		}
	}

done:

	if (fp) {
		fclose(fp);
	}

	return address;
}

auto memory::getAbsoluteAddress(const char* libraryName, std::uint64_t relativeAddr) -> std::uint64_t
{
	libBase = findLibrary(libraryName);
	if (libBase == 0)
		return 0;
	return libBase + relativeAddr;
}
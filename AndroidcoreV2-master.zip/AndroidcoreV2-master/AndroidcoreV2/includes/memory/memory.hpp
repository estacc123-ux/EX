#pragma once
#include <cstdint>
#include <thread>
#include <cstdio>
#include <string>
#include <fstream>
#include <iostream>
#include <dlfcn.h>

namespace memory {
    auto getAbsoluteAddress(const char* libraryName, std::uint64_t relativeAddr) -> std::uint64_t;
    auto findLibrary(const char* library) -> std::uint64_t;
}
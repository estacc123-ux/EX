#pragma once

namespace androidcore::dependencies {
	constexpr const char* name = "Androidcore";
	constexpr const char* version = "2.0.0";
	constexpr const char* chunk = "@AndroidCore";
}
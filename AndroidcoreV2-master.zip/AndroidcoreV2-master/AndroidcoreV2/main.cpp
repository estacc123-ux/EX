#include "includes/memory/memory.hpp"
#include "includes/updates/updates.hpp"
#include "includes/updates/hooks.hpp"

auto start() -> void
{
	LOGD("Waiting for Roblox");
	memory::findLibrary("libroblox.so");

	// Initiate our hooks & addresses
	androidcore::attach();
	androidcore::hooks::attach();

	LOGD("Exploit environment starting up..");
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    start();

    return JNI_VERSION_1_6;
}
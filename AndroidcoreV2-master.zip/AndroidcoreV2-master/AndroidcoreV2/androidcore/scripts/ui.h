#pragma once
#include <string>

std::string ui = R"(
print(game.PlaceId)
print("AndroidCore real")
)";
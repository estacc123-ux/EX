#pragma once
#include "../includes/updates/updates.hpp"

#include <queue>
#include <string>
#include <lstate.h>
#include <lua.h>
#include <lualib.h>
#include <Luau/Common.h>
#include <ltable.h>
#include <Luau/ExperimentalFlags.h>

namespace androidcore {
	class environment {
	private:
		lua_State* aL;
		lua_State* eL;

	public:
		static environment& GetSingleton() {
			static environment instance;
			return instance;
		}

		auto grabaL() -> lua_State* { return this->aL; }
		auto grabeL() -> lua_State* { return this->eL; }

		auto start(int64_t sc) -> void;
		auto initiate(int64_t placeid) -> void;
	};
}
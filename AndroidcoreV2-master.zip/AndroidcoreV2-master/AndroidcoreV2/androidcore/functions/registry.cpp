#include "registry.hpp"

static int libsize(const luaL_Reg* l)
{
    int size = 0;
    for (; l->name; l++)
        size++;
    return size;
}

auto androidcore::registry::filler(lua_State* ls) -> int
{
    return 0;
}

auto androidcore::registry::createlib(lua_State* ls, const char* libname, const luaL_Reg* lib) -> void
{
    if (libname)
    {
        int nfunc = libsize(lib);
        lua_createtable(ls, 0, nfunc);

        for (; lib->name; lib++)
        {
            androidcore::closures::pushcclosure(ls, lib->func, lib->name, 0);
            lua_setfield(ls, -2, lib->name);
        }

        lua_setreadonly(ls, -1, true);
        lua_setfield(ls, -2, libname);
    }
    else if (libname == nullptr)
    {
        for (; lib->name; lib++)
        {
            androidcore::closures::pushcclosure(ls, lib->func, lib->name, 0);
            lua_setfield(ls, -2, lib->name);
        }
    }
}
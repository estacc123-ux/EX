#pragma once

#include <lua.h>
#include <lualib.h>
#include "../../includes/closures/closures.hpp"

namespace androidcore::registry {
	auto filler(lua_State* ls) -> int;
	auto createlib(lua_State* ls, const char* libname, const luaL_Reg* lib) -> void;

	auto metatables(lua_State* ls) -> void;
}
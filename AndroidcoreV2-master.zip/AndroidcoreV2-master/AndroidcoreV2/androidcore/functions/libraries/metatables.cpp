#include "../registry.hpp"
#include <dependencies.h>

static int identifyexecutor(lua_State* ls)
{
	LOGD("Attempting to call identifyexecutor");
	lua_pushstring(ls, androidcore::dependencies::name);
	lua_pushstring(ls, androidcore::dependencies::version);
	return 2;
}

static const luaL_Reg global_funcs[] = {
	{"identifyexecutor", identifyexecutor},
	{nullptr, nullptr}
};

auto androidcore::registry::metatables(lua_State* ls) -> void
{
	createlib(ls, nullptr, global_funcs);
}
#pragma once

#include <string>
#include <tuple>
#include <lua.h>
#include <Luau/Compiler.h>
#include <Luau/BytecodeBuilder.h>
#include <Luau/BytecodeUtils.h>
#include <queue>

#include "../environment.hpp"

namespace androidcore {
    class bytecode_encoder_t : public Luau::BytecodeEncoder {
        inline void encode(uint32_t* data, size_t count) override
        {
            for (auto i = 0u; i < count; )
            {
                auto& opcode = *reinterpret_cast<uint8_t*>(data + i);
                i += Luau::getOpLength(LuauOpcode(opcode));
                opcode *= 227;
            }
        }
    };

    class execution {
    public:
        static execution& GetSingleton() {
            static execution instance;
            return instance;
        }

        auto compile(const std::string& script) -> void;
    };
}
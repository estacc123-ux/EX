#include "execution.hpp"
#include <dependencies.h>

auto androidcore::execution::compile(const std::string& script) -> void
{
	auto ls = androidcore::rbx_luanewthread(androidcore::environment::GetSingleton().grabaL());
	lua_pop(androidcore::environment::GetSingleton().grabaL(), 1);

	static auto encoder = bytecode_encoder_t();
	const auto bytecode = Luau::compile(script, { 1, 1, 2 }, { true, true }, &encoder);
	
	if (androidcore::rbx_luauload(ls, androidcore::dependencies::chunk, bytecode.c_str(), bytecode.size(), 0) != 0)
	{
		const auto error = lua_tostring(ls, -1);
		androidcore::rbx_stdout(structs::warn, "%s", error);

		LOGE("Error while handling script.");
		return;
	}

	lua_call(ls, 1, 0);
	lua_pop(ls, 1);
}
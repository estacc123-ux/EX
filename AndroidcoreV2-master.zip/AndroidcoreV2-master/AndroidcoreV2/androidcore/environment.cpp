#include "environment.hpp"
#include "execution/execution.hpp"
#include "scripts/ui.h"
#include "functions/registry.hpp"

auto androidcore::environment::start(int64_t sc) -> void
{
	LOGD("Attempting to call androidcore::environment::start");
	if (sc == 0)
	{
		LOGE("Failed to find Provider");
		return;
	}

	this->aL = androidcore::grabGlobalState(sc);
	if (this->aL == 0)
	{
		LOGE("Failed to grab ROBLOX Global state");
		return;
	}

	this->eL = androidcore::rbx_luanewthread(this->aL);
	if (this->eL == 0)
	{
		LOGE("Failed to newthread the current sc");
		return;
	}
}

auto androidcore::environment::initiate(int64_t placeid) -> void
{
	LOGD("Attempting to call androidcore::environment::initiate");
	if (placeid == 0)
	{
		LOGE("Current PlaceId is not a valid game");
		return;
	}

	for (Luau::FValue<bool>* flag = Luau::FValue<bool>::list; flag; flag = flag->next)
	{
		if (strncmp(flag->name, "Luau", 4) == 0)
		{
			flag->value = true;
		}
	}

	auto rL = this->eL;
	lua_getglobal(rL, "game");
	lua_getfield(rL, -1, "PlaceId");
	const auto stored_placeid = luaL_optinteger(rL, -1, 0);
	lua_pop(rL, 2);

	if (stored_placeid == 0)
	{
		LOGD("PlaceId for DM is 0!");
		return;
	}

	// register our functions
	androidcore::registry::metatables(rL);

	// Execute our script
	androidcore::execution::GetSingleton().compile(ui);
}
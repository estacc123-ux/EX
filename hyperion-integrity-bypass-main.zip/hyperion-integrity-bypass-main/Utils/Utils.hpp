#pragma once

#include <string>

namespace Utils::Logger
{
    void Log(const std::string& Format, ...);
}
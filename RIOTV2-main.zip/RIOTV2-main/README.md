# RIOT V2

Authored by biggaboy212

## Project Setup

### Extensions used (biggaboy212)

[Luau Language Server](https://marketplace.visualstudio.com/items?itemName=JohnnyMorganz.luau-lsp)

[Error Lens](https://marketplace.visualstudio.com/items?itemName=usernamehw.errorlens)

### To Build

Install Lune and Darklua, as this uses ProCMP

Use the keybind ***Ctrl + Shift + B*** to build
